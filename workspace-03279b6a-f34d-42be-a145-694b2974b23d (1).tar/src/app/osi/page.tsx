import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Layers, BookOpen, ArrowDown, ArrowUp } from "lucide-react";

export default function OSIPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      {/* Header */}
      <div className="mb-12">
        <div className="flex items-center gap-3 mb-4">
          <Layers className="h-10 w-10 text-primary" />
          <div>
            <h1 className="text-3xl md:text-4xl font-bold">Modelo OSI</h1>
            <p className="text-muted-foreground text-lg">Open Systems Interconnection - As 7 Camadas da Comunicação de Rede</p>
          </div>
        </div>
        <Alert className="border-amber-500/50 bg-amber-500/10">
          <BookOpen className="h-4 w-4 text-amber-500" />
          <AlertDescription className="text-amber-200">
            <strong>Foco em Prova:</strong> Conhecer as 7 camadas, PDU de cada camada e exemplos de protocolos é ESSENCIAL para qualquer certificação de rede.
          </AlertDescription>
        </Alert>
      </div>

      {/* Visão Geral das Camadas */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle>Visão Geral das 7 Camadas</CardTitle>
          <CardDescription>Do físico à aplicação, cada camada tem sua função específica</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {[
              { layer: 7, name: "Application", pdu: "Data", color: "bg-purple-500/20 border-purple-500" },
              { layer: 6, name: "Presentation", pdu: "Data", color: "bg-pink-500/20 border-pink-500" },
              { layer: 5, name: "Session", pdu: "Data", color: "bg-rose-500/20 border-rose-500" },
              { layer: 4, name: "Transport", pdu: "Segment/Datagram", color: "bg-orange-500/20 border-orange-500" },
              { layer: 3, name: "Network", pdu: "Packet", color: "bg-amber-500/20 border-amber-500" },
              { layer: 2, name: "Data Link", pdu: "Frame", color: "bg-emerald-500/20 border-emerald-500" },
              { layer: 1, name: "Physical", pdu: "Bit", color: "bg-cyan-500/20 border-cyan-500" },
            ].map((item) => (
              <div key={item.layer} className={`flex items-center justify-between p-3 rounded-lg border ${item.color}`}>
                <div className="flex items-center gap-4">
                  <Badge variant="outline" className="text-lg font-bold w-12 h-12 flex items-center justify-center">
                    {item.layer}
                  </Badge>
                  <div>
                    <p className="font-semibold">{item.name}</p>
                    <p className="text-sm text-muted-foreground">PDU: {item.pdu}</p>
                  </div>
                </div>
                <ArrowDown className="h-5 w-5 text-muted-foreground hidden md:block" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Encapsulamento */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle>Processo de Encapsulamento e Desencapsulamento</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <ArrowDown className="h-5 w-5 text-primary" />
                Encapsulamento (Envio)
              </h4>
              <div className="text-sm space-y-1">
                <p>Application → Data</p>
                <p>Presentation → Data + Formato</p>
                <p>Session → Data + Sessão</p>
                <p>Transport → Data + Header (Segment)</p>
                <p>Network → Segment + Header (Packet)</p>
                <p>Data Link → Packet + Header/Trailer (Frame)</p>
                <p>Physical → Frame → Bits (0s e 1s)</p>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <ArrowUp className="h-5 w-5 text-primary" />
                Desencapsulamento (Recebimento)
              </h4>
              <div className="text-sm space-y-1">
                <p>Physical → Bits → Frame</p>
                <p>Data Link → Frame → Packet</p>
                <p>Network → Packet → Segment</p>
                <p>Transport → Segment → Data</p>
                <p>Session → Data + Gerenciamento</p>
                <p>Presentation → Data + Decodificação</p>
                <p>Application → Data para Usuário</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Camada 7 - Application */}
      <Card className="mb-6 border-2 border-l-purple-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge className="text-lg">7</Badge>
            Camada de Aplicação (Application Layer)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm"><strong>Função:</strong> Interface entre o software do usuário e a rede. Fornece serviços de rede diretamente às aplicações.</p>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="http">
              <AccordionTrigger className="text-left text-sm font-medium">🌐 HTTP/HTTPS</AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <div className="p-3 bg-purple-500/10 rounded">
                  <p><strong>HTTP (Hypertext Transfer Protocol):</strong></p>
                  <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                    <li><strong>Métodos:</strong> GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS, TRACE</li>
                    <li><strong>Códigos de Status:</strong> 2xx (sucesso), 3xx (redirecionamento), 4xx (erro cliente), 5xx (erro servidor)</li>
                    <li><strong>Sem estado:</strong> Cada requisição é independente</li>
                    <li><strong>Porta:</strong> 80 (HTTP), 443 (HTTPS)</li>
                  </ul>
                </div>
                <div className="p-3 bg-emerald-500/10 rounded">
                  <p><strong>HTTPS (HTTP Secure):</strong></p>
                  <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                    <li><strong>Handshake TLS:</strong> Client Hello → Server Hello → Certificate → Key Exchange → Finished</li>
                    <li><strong>Cipher Suites:</strong> Algoritmos de criptografia (AES, ChaCha20)</li>
                    <li><strong>Certificados:</strong> X.509, validação por CA</li>
                  </ul>
                </div>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="dns">
              <AccordionTrigger className="text-left text-sm font-medium">🔍 DNS (Domain Name System)</AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Função:</strong> Traduz nomes de domínio para endereços IP</p>
                <div className="grid md:grid-cols-2 gap-2 mt-2">
                  <div className="p-2 bg-muted rounded">
                    <p className="font-semibold">Tipos de Registros</p>
                    <ul className="list-disc list-inside ml-4 text-xs space-y-1 mt-1">
                      <li>A → IPv4</li>
                      <li>AAAA → IPv6</li>
                      <li>CNAME → Alias</li>
                      <li>MX → Mail Server</li>
                      <li>TXT → Texto</li>
                      <li>NS → Name Server</li>
                    </ul>
                  </div>
                  <div className="p-2 bg-muted rounded">
                    <p className="font-semibold">Servidores DNS</p>
                    <ul className="list-disc list-inside ml-4 text-xs space-y-1 mt-1">
                      <li>Root Servers (.)</li>
                      <li>TLD Servers (.com, .br)</li>
                      <li>Authoritative</li>
                      <li>Recursive/Resolver</li>
                    </ul>
                  </div>
                </div>
                <p className="mt-2"><strong>Processo de Resolução:</strong> Cache → Recursive → Root → TLD → Authoritative</p>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="email">
              <AccordionTrigger className="text-left text-sm font-medium">📧 Protocolos de Email</AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <div className="p-3 bg-blue-500/10 rounded">
                  <p><strong>SMTP (Simple Mail Transfer Protocol) - Porta 25/587:</strong></p>
                  <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                    <li>Envio de emails</li>
                    <li>Entre servidores MTA</li>
                    <li>Texto claro (STARTTLS opcional)</li>
                  </ul>
                </div>
                <div className="p-3 bg-emerald-500/10 rounded">
                  <p><strong>IMAP (Internet Message Access Protocol) - Porta 143/993:</strong></p>
                  <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                    <li>Acesso a emails no servidor</li>
                    <li>Sincronização entre dispositivos</li>
                    <li>Pastas no servidor</li>
                  </ul>
                </div>
                <div className="p-3 bg-amber-500/10 rounded">
                  <p><strong>POP3 (Post Office Protocol v3) - Porta 110/995:</strong></p>
                  <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                    <li>Baixa emails para cliente</li>
                    <li>Remove do servidor (por padrão)</li>
                    <li>Sem sincronização</li>
                  </ul>
                </div>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="ssh-ftp">
              <AccordionTrigger className="text-left text-sm font-medium">🔐 SSH e FTP</AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>SSH (Secure Shell) - Porta 22:</strong></p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li>Acesso remoto seguro</li>
                  <li>Autenticação por chave ou senha</li>
                  <li>Criptografia forte</li>
                  <li>SSH tunneling/port forwarding</li>
                </ul>
                <p className="mt-2"><strong>FTP (File Transfer Protocol) - Portas 20/21:</strong></p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li>Transferência de arquivos</li>
                  <li>Modo Ativo vs Passivo</li>
                  <li>SFTP (FTP sobre SSH) é mais seguro</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Camada 6 - Presentation */}
      <Card className="mb-6 border-2 border-l-pink-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge className="text-lg">6</Badge>
            Camada de Apresentação (Presentation Layer)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm"><strong>Função:</strong> Tradução, criptografia, compressão e formatação de dados para que a camada de aplicação possa entender.</p>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="ssl-tls">
              <AccordionTrigger className="text-left text-sm font-medium">🔒 SSL/TLS</AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Versões:</strong> SSL 2.0/3.0 (obsoletas/inseguras), TLS 1.0/1.1 (obsoletas), TLS 1.2/1.3 (atuais)</p>
                <p><strong>Componentes do Handshake:</strong></p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li><strong>Negotiation:</strong> Versão TLS, cipher suite</li>
                  <li><strong>Authentication:</strong> Troca de certificados (Server auth, opcional Client auth)</li>
                  <li><strong>Key Exchange:</strong> Diffie-Hellman, RSA, ECDHE</li>
                  <li><strong>Finished:</strong> Verificação da chave mestra</li>
                </ul>
                <p className="mt-2"><strong>Cipher Suite Exemplo:</strong> TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384</p>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="formatacao">
              <AccordionTrigger className="text-left text-sm font-medium">📝 Formatação e Compressão</AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Formatação de Dados:</strong></p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li>ASCII, Unicode (UTF-8, UTF-16)</li>
                  <li>JSON, XML, YAML</li>
                  <li>Binary formats (protobuf, Avro)</li>
                </ul>
                <p className="mt-2"><strong>Compressão:</strong></p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li>GZIP, DEFLATE (HTTP)</li>
                  <li>ZIP, RAR (arquivos)</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Camada 5 - Session */}
      <Card className="mb-6 border-2 border-l-rose-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge className="text-lg">5</Badge>
            Camada de Sessão (Session Layer)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm"><strong>Função:</strong> Estabelece, gerencia e termina sessões entre aplicações. Controla diálogo e sincronização.</p>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="protocolos">
              <AccordionTrigger className="text-left text-sm font-medium">🤝 Protocolos</AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <div className="p-3 bg-rose-500/10 rounded">
                  <p><strong>NetBIOS:</strong></p>
                  <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                    <li>Nomeação de rede (NetBIOS names)</li>
                    <li>Sessões entre aplicações Windows</li>
                    <li>WINS para resolução de nomes</li>
                  </ul>
                </div>
                <div className="p-3 bg-purple-500/10 rounded">
                  <p><strong>RPC (Remote Procedure Call):</strong></p>
                  <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                    <li>Executa funções em máquina remota</li>
                    <li>Usado em Windows (DCOM), NFS</li>
                    <li>Chamadas síncronas</li>
                  </ul>
                </div>
                <div className="p-3 bg-blue-500/10 rounded">
                  <p><strong>SMB (Server Message Block):</strong></p>
                  <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                    <li>Compartilhamento de arquivos/impressoras</li>
                    <li>Portas 445 (SMB over TCP), 139 (NetBIOS)</li>
                    <li>Autenticação NTLM, Kerberos</li>
                  </ul>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Camada 4 - Transport */}
      <Card className="mb-6 border-2 border-l-orange-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge className="text-lg">4</Badge>
            Camada de Transporte (Transport Layer)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm"><strong>Função:</strong> Comunicação fim-a-fim, controle de fluxo, correção de erros e multiplexação.</p>
          <Alert className="border-primary/50 bg-primary/10">
            <BookOpen className="h-4 w-4 text-primary" />
            <AlertDescription className="text-primary-foreground">
              <strong>Foco em Prova:</strong> TCP vs UDP é um dos tópicos MAIS importantes. Entenda as diferenças e quando usar cada um.
            </AlertDescription>
          </Alert>
          <div className="grid md:grid-cols-2 gap-4">
            <Card className="border-l-4 border-l-blue-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">TCP (Transmission Control Protocol)</CardTitle>
              </CardHeader>
              <CardContent className="text-sm space-y-2">
                <p><strong>Características:</strong></p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li>Orientado à conexão</li>
                  <li>Confiável (confirmação de entrega)</li>
                  <li>Ordenado (sequência de pacotes)</li>
                  <li>Controle de fluxo</li>
                  <li>Controle de congestionamento</li>
                </ul>
                <p className="mt-2"><strong>Handshake TCP (3-Way):</strong></p>
                <p className="font-mono text-xs">SYN → SYN-ACK → ACK</p>
                <p className="mt-2"><strong>Terminação (4-Way):</strong></p>
                <p className="font-mono text-xs">FIN → ACK → FIN → ACK</p>
              </CardContent>
            </Card>
            <Card className="border-l-4 border-l-purple-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">UDP (User Datagram Protocol)</CardTitle>
              </CardHeader>
              <CardContent className="text-sm space-y-2">
                <p><strong>Características:</strong></p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li>Sem conexão</li>
                  <li>Não confiável (sem confirmação)</li>
                  <li>Sem ordenação</li>
                  <li>Leve e rápido</li>
                  <li>Baixa latência</li>
                </ul>
                <p className="mt-2"><strong>Uso Típico:</strong></p>
                <ul className="list-disc list-inside ml-4 space-y-1 text-xs">
                  <li>Streaming de vídeo/áudio</li>
                  <li>DNS queries</li>
                  <li>VoIP</li>
                  <li>Gaming</li>
                </ul>
              </CardContent>
            </Card>
          </div>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="portas">
              <AccordionTrigger className="text-left text-sm font-medium">🔌 Portas Bem Conhecidas</AccordionTrigger>
              <AccordionContent className="pt-2 text-sm">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {[
                    { port: "20/21", service: "FTP" },
                    { port: "22", service: "SSH" },
                    { port: "23", service: "Telnet" },
                    { port: "25", service: "SMTP" },
                    { port: "53", service: "DNS" },
                    { port: "67/68", service: "DHCP" },
                    { port: "80", service: "HTTP" },
                    { port: "110", service: "POP3" },
                    { port: "123", service: "NTP" },
                    { port: "143", service: "IMAP" },
                    { port: "443", service: "HTTPS" },
                    { port: "445", service: "SMB" },
                    { port: "3306", service: "MySQL" },
                    { port: "3389", service: "RDP" },
                    { port: "5432", service: "PostgreSQL" },
                    { port: "5900", service: "VNC" },
                  ].map((item) => (
                    <div key={item.port} className="p-2 bg-muted rounded text-center">
                      <p className="font-semibold">{item.port}</p>
                      <p className="text-xs text-muted-foreground">{item.service}</p>
                    </div>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Camada 3 - Network */}
      <Card className="mb-6 border-2 border-l-amber-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge className="text-lg">3</Badge>
            Camada de Rede (Network Layer)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm"><strong>Função:</strong> Roteamento, endereçamento lógico e determinação do melhor caminho.</p>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="ipv4-ipv6">
              <AccordionTrigger className="text-left text-sm font-medium">🌍 IPv4 vs IPv6</AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-3 bg-amber-500/10 rounded">
                    <p className="font-semibold">IPv4</p>
                    <ul className="list-disc list-inside ml-4 mt-1 space-y-1 text-xs">
                      <li>32 bits (4 octetos)</li>
                      <li>Formato decimal: 192.168.1.1</li>
                      <li>~4.3 bilhões de endereços</li>
                      <li>NAT para conservação</li>
                      <li>Header de 20-60 bytes</li>
                    </ul>
                  </div>
                  <div className="p-3 bg-emerald-500/10 rounded">
                    <p className="font-semibold">IPv6</p>
                    <ul className="list-disc list-inside ml-4 mt-1 space-y-1 text-xs">
                      <li>128 bits (8 grupos de 16 bits)</li>
                      <li>Formato hex: 2001:db8::1</li>
                      <li>~3.4×10³⁸ endereços</li>
                      <li>Sem NAT necessário</li>
                      <li>Header de 40 bytes fixo</li>
                    </ul>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="icmp-arp">
              <AccordionTrigger className="text-left text-sm font-medium">📡 ICMP e ARP</AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <div className="p-3 bg-blue-500/10 rounded">
                  <p><strong>ICMP (Internet Control Message Protocol):</strong></p>
                  <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                    <li>Diagnóstico e erro (ping, traceroute)</li>
                    <li>Type 8: Echo Request (ping)</li>
                    <li>Type 0: Echo Reply (pong)</li>
                    <li>Type 3: Destination Unreachable</li>
                    <li>Type 11: Time Exceeded (TTL)</li>
                  </ul>
                </div>
                <div className="p-3 bg-purple-500/10 rounded">
                  <p><strong>ARP (Address Resolution Protocol):</strong></p>
                  <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                    <li>Traduz IP → MAC address</li>
                    <li>ARP Request: broadcast</li>
                    <li>ARP Reply: unicast</li>
                    <li>ARP Cache: tabela de mapeamentos</li>
                    <li>Gratuitous ARP: detecta duplicados</li>
                  </ul>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Camada 2 - Data Link */}
      <Card className="mb-6 border-2 border-l-emerald-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge className="text-lg">2</Badge>
            Camada de Enlace (Data Link Layer)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm"><strong>Função:</strong> Endereçamento físico (MAC), controle de acesso ao meio, detecção de erros.</p>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="ethernet">
              <AccordionTrigger className="text-left text-sm font-medium">🔌 Ethernet</AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>MAC Address (48 bits):</strong></p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li>Formato: XX:XX:XX:XX:XX:XX (hex)</li>
                  <li>OUI (24 bits): Vendor ID</li>
                  <li>NIC Specific (24 bits)</li>
                  <li>Unicast vs Multicast vs Broadcast</li>
                </ul>
                <p className="mt-2"><strong>Ethernet Frame:</strong></p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li>Preamble (8 bytes)</li>
                  <li>Destination MAC (6 bytes)</li>
                  <li>Source MAC (6 bytes)</li>
                  <li>Type/EtherType (2 bytes)</li>
                  <li>Data (46-1500 bytes)</li>
                  <li>FCS/CRC (4 bytes)</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="vlan">
              <AccordionTrigger className="text-left text-sm font-medium">🏷️ VLAN 802.1Q</AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>802.1Q Tag (4 bytes):</strong></p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li>TPID: 0x8100</li>
                  <li>Priority: 3 bits (QoS)</li>
                  <li>CFI: 1 bit</li>
                  <li>VLAN ID: 12 bits (1-4094)</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Camada 1 - Physical */}
      <Card className="mb-8 border-2 border-l-cyan-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge className="text-lg">1</Badge>
            Camada Física (Physical Layer)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm"><strong>Função:</strong> Transmissão de bits brutos sobre meio físico. Especifica hardware, cabos, sinais elétricos.</p>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="cabos">
              <AccordionTrigger className="text-left text-sm font-medium">🔗 Tipos de Cabos</AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <div className="space-y-2">
                  <p><strong>Cabo de Par Trançado (Twisted Pair):</strong></p>
                  <ul className="list-disc list-inside ml-4 space-y-1 text-xs">
                    <li>Cat5e: até 1 Gbps, 100 MHz</li>
                    <li>Cat6: até 10 Gbps, 250 MHz (até 55m)</li>
                    <li>Cat6a: até 10 Gbps, 500 MHz (100m)</li>
                    <li>Cat8: até 40 Gbps, 2000 MHz</li>
                  </ul>
                  <p className="mt-2"><strong>Fibra Óptica:</strong></p>
                  <ul className="list-disc list-inside ml-4 space-y-1 text-xs">
                    <li>MMF (Multimode): até 2km, 850/1300nm</li>
                    <li>SMF (Singlemode): até 100km+, 1310/1550nm</li>
                    <li>Connectores: LC, SC, ST, MPO</li>
                  </ul>
                </div>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="codificacao">
              <AccordionTrigger className="text-left text-sm font-medium">⚡ Codificação de Sinais</AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>10/100 Mbps:</strong> Manchester encoding</p>
                <p><strong>1 Gbps:</strong> 8b/10b encoding</p>
                <p><strong>10 Gbps+:</strong> 64b/66b encoding</p>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>
    </div>
  );
}
