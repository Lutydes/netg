import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Shield, AlertTriangle, BookOpen, CheckCircle2, XCircle, Network } from "lucide-react";

export default function HardwarePage() {
  return (
    <div className="container mx-auto px-4 py-12">
      {/* Header */}
      <div className="mb-12">
        <div className="flex items-center gap-3 mb-4">
          <Shield className="h-10 w-10 text-primary" />
          <div>
            <h1 className="text-3xl md:text-4xl font-bold">Hardware de Rede</h1>
            <p className="text-muted-foreground text-lg">Dispositivos, Protocolos e Tecnologias de Infraestrutura</p>
          </div>
        </div>
        <Alert className="border-amber-500/50 bg-amber-500/10">
          <BookOpen className="h-4 w-4 text-amber-500" />
          <AlertDescription className="text-amber-200">
            <strong>Foco em Prova:</strong> Esta seção contém conceitos frequentemente cobrados em certificações como CCNA, CompTIA Network+ e exames de vendors.
          </AlertDescription>
        </Alert>
      </div>

      {/* HUBS */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Network className="h-6 w-6 text-primary" />
            Hubs (Repetidores Múltiplos)
          </CardTitle>
          <CardDescription>Dispositivos da Camada 1 do Modelo OSI - Operam no nível físico</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-lg">
            <h4 className="font-semibold flex items-center gap-2 text-destructive mb-2">
              <XCircle className="h-4 w-4" />
              Características Principais (Desvantagens)
            </h4>
            <ul className="list-disc list-inside space-y-1 text-sm">
              <li><strong>Transmite para todos:</strong> Todo tráfego é enviado para todas as portas (broadcast domain único)</li>
              <li><strong>Sem inteligência:</strong> Não lê endereços MAC, apenas repete sinais elétricos</li>
              <li><strong>Domínio de colisão compartilhado:</strong> Todos os dispositivos no mesmo domínio de colisão</li>
              <li><strong>Sem CSMA/CD eficaz:</strong> Alta taxa de colisões em redes grandes</li>
              <li><strong>Half-duplex apenas:</strong> Não pode enviar e receber simultaneamente</li>
              <li><strong>Banda passante dividida:</strong> 100Mbps compartilhado entre todos os dispositivos</li>
            </ul>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="funcionamento">
              <AccordionTrigger className="text-left">
                <span className="font-medium">🔧 Como Funciona</span>
              </AccordionTrigger>
              <AccordionContent className="space-y-3 pt-3">
                <div className="p-4 bg-muted/50 rounded-lg space-y-2 text-sm">
                  <p><strong>Processo de Operação:</strong></p>
                  <ol className="list-decimal list-inside space-y-2 ml-4">
                    <li><strong>Recebimento:</strong> Um hub recebe um sinal elétrico em uma porta</li>
                    <li><strong>Regeneração:</strong> O sinal é amplificado e regenerado (repeater function)</li>
                    <li><strong>Replicação:</strong> O sinal regenerado é enviado para TODAS as outras portas simultaneamente</li>
                    <li><strong>Sem Filtragem:</strong> Não há análise de destino - todos recebem tudo</li>
                  </ol>
                </div>
                <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg">
                  <p className="text-sm"><strong>⚠️ Exemplo Prático:</strong> Em um hub com 5 computadores conectados em 100Mbps, cada computador teoricamente tem 20Mbps disponível (100/5), mas devido a colisões, a velocidade real é muito menor.</p>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="tipos">
              <AccordionTrigger className="text-left">
                <span className="font-medium">📦 Tipos de Hubs</span>
              </AccordionTrigger>
              <AccordionContent className="space-y-3 pt-3">
                <div className="space-y-3">
                  <Card className="border-l-4 border-l-emerald-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base">Passive Hub</CardTitle>
                    </CardHeader>
                    <CardContent className="text-sm">
                      <p><strong>Funcionamento:</strong> Apenas recebe e retransmite o sinal sem amplificação</p>
                      <p><strong>Uso:</strong> Cabos curtos, pouco comum atualmente</p>
                      <p><strong>Limitação:</strong> Sinal degrada com a distância</p>
                    </CardContent>
                  </Card>
                  <Card className="border-l-4 border-l-blue-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base">Active Hub (Repeater)</CardTitle>
                    </CardHeader>
                    <CardContent className="text-sm">
                      <p><strong>Funcionamento:</strong> Amplifica e regenera o sinal elétrico</p>
                      <p><strong>Uso:</strong> Extensão de redes, supera limitações de distância</p>
                      <p><strong>Benefício:</strong> Pode conectar segmentos mais longos</p>
                    </CardContent>
                  </Card>
                  <Card className="border-l-4 border-l-purple-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base">Intelligent Hub (Stackable)</CardTitle>
                    </CardHeader>
                    <CardContent className="text-sm">
                      <p><strong>Funcionamento:</strong> Pode ser gerenciado, permite diagnóstico básico</p>
                      <p><strong>Uso:</strong> Ambientes corporativos que precisam de gerenciamento</p>
                      <p><strong>Limitação:</strong> Ainda opera na Camada 1, sem filtragem</p>
                    </CardContent>
                  </Card>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="comparacao">
              <AccordionTrigger className="text-left">
                <span className="font-medium">📊 Hub vs Switch</span>
              </AccordionTrigger>
              <AccordionContent className="pt-3">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-2">Característica</th>
                        <th className="text-left p-2">Hub</th>
                        <th className="text-left p-2">Switch</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b">
                        <td className="p-2 font-medium">Camada OSI</td>
                        <td className="p-2">Camada 1 (Física)</td>
                        <td className="p-2">Camada 2 (Enlace) / Camada 3</td>
                      </tr>
                      <tr className="border-b">
                        <td className="p-2 font-medium">Endereçamento</td>
                        <td className="p-2">Nenhum</td>
                        <td className="p-2">Endereços MAC / IP</td>
                      </tr>
                      <tr className="border-b">
                        <td className="p-2 font-medium">Transmissão</td>
                        <td className="p-2">Broadcast para todos</td>
                        <td className="p-2">Unicast (destino específico)</td>
                      </tr>
                      <tr className="border-b">
                        <td className="p-2 font-medium">Domínio de Colisão</td>
                        <td className="p-2">Único (compartilhado)</td>
                        <td className="p-2">Um por porta</td>
                      </tr>
                      <tr className="border-b">
                        <td className="p-2 font-medium">Banda Passante</td>
                        <td className="p-2">Compartilhada</td>
                        <td className="p-2">Dedicada por porta</td>
                      </tr>
                      <tr className="border-b">
                        <td className="p-2 font-medium">Duplex</td>
                        <td className="p-2">Half-duplex</td>
                        <td className="p-2">Full-duplex</td>
                      </tr>
                      <tr>
                        <td className="p-2 font-medium">Inteligência</td>
                        <td className="p-2">Nenhuma</td>
                        <td className="p-2">Tabela de endereçamento</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* BRIDGES */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Network className="h-6 w-6 text-primary" />
            Bridges (Pontes)
          </CardTitle>
          <CardDescription>Dispositivos da Camada 2 do Modelo OSI - Operam no nível de enlace</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-lg">
            <h4 className="font-semibold flex items-center gap-2 text-emerald-500 mb-2">
              <CheckCircle2 className="h-4 w-4" />
              Características Principais
            </h4>
            <ul className="list-disc list-inside space-y-1 text-sm">
              <li><strong>Opera na Camada 2:</strong> Lê endereços MAC dos quadros</li>
              <li><strong>Segmenta domínios de colisão:</strong> Cada porta é um domínio de colisão separado</li>
              <li><strong>Tabela de endereços MAC:</strong> Aprende quais MACs estão em cada porta</li>
              <li><strong>Filtering:</strong> Só encaminha tráfego para o segmento correto</li>
              <li><strong>Software-based:</strong> Processamento geralmente em software (mais lento que switch)</li>
            </ul>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="funcionamento">
              <AccordionTrigger className="text-left">
                <span className="font-medium">🔧 Como Funciona</span>
              </AccordionTrigger>
              <AccordionContent className="space-y-3 pt-3">
                <div className="p-4 bg-muted/50 rounded-lg space-y-2 text-sm">
                  <p><strong>Processo de Aprendizado e Encaminhamento:</strong></p>
                  <ol className="list-decimal list-inside space-y-2 ml-4">
                    <li><strong>Aprendizado:</strong> Quando recebe um quadro, anota o MAC de origem e a porta de entrada</li>
                    <li><strong>Armazenamento:</strong> Atualiza a tabela de endereços MAC (CAM table)</li>
                    <li><strong>Decisão:</strong> Verifica o MAC de destino na tabela</li>
                    <li><strong>Encaminhamento:</strong>
                      <ul className="list-disc list-inside ml-4 mt-1">
                        <li>Se MAC encontrado na tabela → envia apenas para aquela porta</li>
                        <li>Se MAC não encontrado → faz flood para todas as portas (exceto origem)</li>
                      </ul>
                    </li>
                    <li><strong>Aging:</strong> Entradas da tabela expiram após período sem atividade (aging timer)</li>
                  </ol>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="tipos">
              <AccordionTrigger className="text-left">
                <span className="font-medium">📦 Tipos de Bridges</span>
              </AccordionTrigger>
              <AccordionContent className="space-y-3 pt-3">
                <div className="space-y-3">
                  <Card className="border-l-4 border-l-blue-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base">Transparent Bridge</CardTitle>
                    </CardHeader>
                    <CardContent className="text-sm">
                      <p><strong>Funcionamento:</strong> Invisível para os dispositivos de rede, aprende automaticamente</p>
                      <p><strong>Protocolo:</strong> Usa STP (Spanning Tree Protocol) para evitar loops</p>
                      <p><strong>Uso:</strong> Mais comum em redes Ethernet</p>
                    </CardContent>
                  </Card>
                  <Card className="border-l-4 border-l-purple-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base">Source Routing Bridge</CardTitle>
                    </CardHeader>
                    <CardContent className="text-sm">
                      <p><strong>Funcionamento:</strong> O caminho é determinado pela estação de origem</p>
                      <p><strong>Protocolo:</strong> Usa campo de roteamento no quadro</p>
                      <p><strong>Uso:</strong> Redes Token Ring (obsoleto)</p>
                    </CardContent>
                  </Card>
                  <Card className="border-l-4 border-l-amber-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base">Translational Bridge</CardTitle>
                    </CardHeader>
                    <CardContent className="text-sm">
                      <p><strong>Funcionamento:</strong> Converte entre diferentes tipos de rede</p>
                      <p><strong>Exemplos:</strong> Ethernet ↔ Token Ring, diferentes velocidades</p>
                      <p><strong>Uso:</strong> Migração de tecnologias (raro hoje)</p>
                    </CardContent>
                  </Card>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="spanning-tree">
              <AccordionTrigger className="text-left">
                <span className="font-medium">🌳 Spanning Tree Protocol (STP)</span>
              </AccordionTrigger>
              <AccordionContent className="space-y-3 pt-3">
                <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg">
                  <p className="text-sm font-semibold mb-2">⚠️ Importante para Prova:</p>
                  <p className="text-sm">STP é essencial em redes com bridges/switches redundantes para evitar broadcast storms.</p>
                </div>
                <div className="space-y-2 text-sm">
                  <p><strong>Objetivo:</strong> Evitar loops na camada 2</p>
                  <p><strong>Funcionamento:</strong></p>
                  <ul className="list-disc list-inside ml-4 space-y-1">
                    <li>Elege uma <strong>Root Bridge</strong> (menor Bridge ID)</li>
                    <li>Cada bridge elege uma <strong>Root Port</strong> (caminho mais curto para a Root Bridge)</li>
                    <li>Cada segmento elege uma <strong>Designated Port</strong></li>
                    <li>Portas redundantes ficam em <strong>Blocking State</strong></li>
                  </ul>
                  <p className="mt-2"><strong>Versões:</strong> STP (802.1D), RSTP (802.1w), MSTP (802.1s)</p>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* SWITCHES - Simplificado para tamanho do arquivo */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Network className="h-6 w-6 text-primary" />
            Switches (Comutadores)
          </CardTitle>
          <CardDescription>Dispositivos da Camada 2 (e 3) - O coração da rede moderna</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="border-primary/50 bg-primary/10">
            <BookOpen className="h-4 w-4 text-primary" />
            <AlertDescription className="text-primary-foreground">
              <strong>Foco em Prova:</strong> Switches são dispositivos FUNDAMENTAIS. Entender Tabela CAM, VLANs e operação é essencial.
            </AlertDescription>
          </Alert>

          <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-lg">
            <h4 className="font-semibold flex items-center gap-2 text-emerald-500 mb-2">
              <CheckCircle2 className="h-4 w-4" />
              Características Principais
            </h4>
            <ul className="list-disc list-inside space-y-1 text-sm">
              <li><strong>Múltiplos domínios de colisão:</strong> Cada porta é um domínio separado</li>
              <li><strong>Hardware-based (ASIC):</strong> Processamento em hardware, extremamente rápido</li>
              <li><strong>Full-duplex:</strong> Envia e recebe simultaneamente</li>
              <li><strong>Banda dedicada:</strong> Cada porta tem largura de banda completa</li>
              <li><strong>Tabela CAM:</strong> Content Addressable Memory para lookup de MAC</li>
              <li><strong>VLANs:</strong> Segmentação lógica de rede</li>
            </ul>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="tabela-cam">
              <AccordionTrigger className="text-left">
                <span className="font-medium">📋 Tabela CAM (Content Addressable Memory)</span>
              </AccordionTrigger>
              <AccordionContent className="space-y-3 pt-3">
                <p className="text-sm"><strong>Processo de Aprendizado:</strong> Quando um quadro entra, o MAC de origem é aprendido e associado à porta. O aging timer (padrão: 300s) remove entradas inativas.</p>
                <p className="text-sm"><strong>Tipos de Entradas:</strong></p>
                <ul className="list-disc list-inside ml-4 text-sm space-y-1">
                  <li><strong>Dynamic:</strong> Aprendidas automaticamente, expiram por aging</li>
                  <li><strong>Static:</strong> Configuradas manualmente, nunca expiram</li>
                  <li><strong>Secure:</strong> Usadas em Port Security</li>
                </ul>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="switch-l2-l3">
              <AccordionTrigger className="text-left">
                <span className="font-medium">🔄 Switch Layer 2 vs Layer 3 com SVI</span>
              </AccordionTrigger>
              <AccordionContent className="space-y-3 pt-3">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <p className="font-semibold text-sm">Switch Layer 2</p>
                    <ul className="list-disc list-inside ml-4 text-sm space-y-1 mt-2">
                      <li>Opera na Camada 2</li>
                      <li>Encaminha por MAC</li>
                      <li>Não faz roteamento entre VLANs</li>
                      <li>Precisa de roteador externo</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-primary/10 border border-primary/20 rounded-lg">
                    <p className="font-semibold text-sm">Switch Layer 3</p>
                    <ul className="list-disc list-inside ml-4 text-sm space-y-1 mt-2">
                      <li>Opera na Camada 3</li>
                      <li>Encaminha por IP</li>
                      <li>Faz roteamento entre VLANs</li>
                      <li>Usa SVI (Switched Virtual Interface)</li>
                    </ul>
                  </div>
                </div>
                <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg mt-3">
                  <p className="text-sm font-semibold">🎯 SVI:</p>
                  <p className="text-sm mt-1">Interface virtual associada a uma VLAN. Permite roteamento entre VLANs (inter-VLAN routing).</p>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Interfaces WAN/LAN */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle>Interfaces WAN/LAN e Protocolos</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="ppp">
              <AccordionTrigger className="text-left">
                <span className="font-medium">🔗 PPP (Point-to-Point Protocol)</span>
              </AccordionTrigger>
              <AccordionContent className="space-y-3 pt-3">
                <p className="text-sm"><strong>Componentes:</strong> HDLC (encapsulamento), LCP (estabelece enlace), NCP (configura protocolos de rede)</p>
                <p className="text-sm"><strong>Autenticação:</strong> PAP (texto claro) ou CHAP (challenge/response com MD5)</p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="mpls">
              <AccordionTrigger className="text-left">
                <span className="font-medium">🏷️ MPLS (Multiprotocol Label Switching)</span>
              </AccordionTrigger>
              <AccordionContent className="space-y-3 pt-3">
                <p className="text-sm"><strong>Conceito:</strong> Roteia baseado em labels em vez de IP, combinando velocidade de L2 com inteligência de L3</p>
                <p className="text-sm"><strong>Componentes:</strong> LER (borda), LSR (troca labels), LSP (caminho de labels), FEC (classe de encaminhamento)</p>
                <p className="text-sm"><strong>VPNs:</strong> L3 VPN (VRF, RD, RT), L2 VPN (VPLS), EVPN</p>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Gateway Padrão */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle>Gateway Padrão</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm mb-3"><strong>Definição:</strong> Endereço IP do roteador usado para enviar tráfego para redes remotas.</p>
          <p className="text-sm"><strong>Processo:</strong> Dispositivo verifica se destino está na rede local. Se SIM → envia direto. Se NÃO → envia para Gateway.</p>
        </CardContent>
      </Card>

      {/* Firewalls */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle>Firewalls - Stateless vs Stateful</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <Card className="border-l-4 border-l-destructive">
              <CardHeader><CardTitle className="text-base">Stateless</CardTitle></CardHeader>
              <CardContent className="text-sm">
                <p>Analisa cada pacote individualmente, sem contexto. Não mantém tabela de estado.</p>
                <p className="mt-2 text-destructive">⚠️ Não entende conexões, precisa de regra de retorno.</p>
              </CardContent>
            </Card>
            <Card className="border-l-4 border-l-emerald-500">
              <CardHeader><CardTitle className="text-base">Stateful</CardTitle></CardHeader>
              <CardContent className="text-sm">
                <p>Rastreia estado das conexões. Permite automaticamente tráfego de retorno.</p>
                <p className="mt-2 text-emerald-500">✅ Mantém tabela de estado, maior segurança.</p>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>

      {/* IPS/IDS */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle>IPS e IDS</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <Card className="border-l-4 border-l-blue-500">
              <CardHeader><CardTitle className="text-base">IDS</CardTitle></CardHeader>
              <CardContent className="text-sm">
                <p><strong>Intrusion Detection System</strong></p>
                <p>Modo passivo, detecta mas não bloqueia. Emite alertas.</p>
              </CardContent>
            </Card>
            <Card className="border-l-4 border-l-emerald-500">
              <CardHeader><CardTitle className="text-base">IPS</CardTitle></CardHeader>
              <CardContent className="text-sm">
                <p><strong>Intrusion Prevention System</strong></p>
                <p>Modo ativo inline, bloqueia ataques em tempo real.</p>
              </CardContent>
            </Card>
          </div>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="metodos">
              <AccordionTrigger className="text-left">
                <span className="font-medium">🔍 Métodos de Detecção</span>
              </AccordionTrigger>
              <AccordionContent className="pt-3 text-sm space-y-2">
                <p><strong>Signature-Based:</strong> Compara com assinaturas conhecidas. Preciso, mas não detecta zero-day.</p>
                <p><strong>Anomaly-Based:</strong> Detecta desvios do comportamento normal. Detecta zero-day, mas altos falsos positivos.</p>
                <p><strong>Heuristic-Based:</strong> Usa algoritmos para identificar comportamentos suspeitos.</p>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>
    </div>
  );
}
