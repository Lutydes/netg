import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { BarChart3, BookOpen, AlertTriangle, Settings, DollarSign, Activity, ShieldCheck } from "lucide-react";

export default function FCAPSPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      {/* Header */}
      <div className="mb-12">
        <div className="flex items-center gap-3 mb-4">
          <BarChart3 className="h-10 w-10 text-primary" />
          <div>
            <h1 className="text-3xl md:text-4xl font-bold">Gerenciamento FCAPS</h1>
            <p className="text-muted-foreground text-lg">Modelo de Gerenciamento de Redes - ISO Telecom</p>
          </div>
        </div>
        <Alert className="border-amber-500/50 bg-amber-500/10">
          <BookOpen className="h-4 w-4 text-amber-500" />
          <AlertDescription className="text-amber-200">
            <strong>Foco em Prova:</strong> FCAPS é o modelo padrão de gerenciamento de redes. Entenda cada componente e sua aplicação prática.
          </AlertDescription>
        </Alert>
      </div>

      {/* Visão Geral FCAPS */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle>O Modelo FCAPS</CardTitle>
          <CardDescription>Os 5 pilares do gerenciamento de redes de telecomunicações</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm mb-4">
            FCAPS é um modelo de gerenciamento de redes definido pela ISO (International Organization for Standardization) para telecomunicações.
            O acrônimo representa as cinco áreas funcionais do gerenciamento de redes.
          </p>
          <div className="grid md:grid-cols-5 gap-4">
            <Card className="border-2 border-l-4 border-l-red-500 text-center">
              <CardHeader className="pb-2">
                <Badge className="mx-auto mb-2">F</Badge>
                <CardTitle className="text-sm">Fault</CardTitle>
              </CardHeader>
              <CardContent className="text-xs">
                <p>Detecção e correção de falhas</p>
              </CardContent>
            </Card>
            <Card className="border-2 border-l-4 border-l-blue-500 text-center">
              <CardHeader className="pb-2">
                <Badge className="mx-auto mb-2">C</Badge>
                <CardTitle className="text-sm">Configuration</CardTitle>
              </CardHeader>
              <CardContent className="text-xs">
                <p>Gerenciamento de configurações</p>
              </CardContent>
            </Card>
            <Card className="border-2 border-l-4 border-l-emerald-500 text-center">
              <CardHeader className="pb-2">
                <Badge className="mx-auto mb-2">A</Badge>
                <CardTitle className="text-sm">Accounting</CardTitle>
              </CardHeader>
              <CardContent className="text-xs">
                <p>Uso de recursos e billing</p>
              </CardContent>
            </Card>
            <Card className="border-2 border-l-4 border-l-amber-500 text-center">
              <CardHeader className="pb-2">
                <Badge className="mx-auto mb-2">P</Badge>
                <CardTitle className="text-sm">Performance</CardTitle>
              </CardHeader>
              <CardContent className="text-xs">
                <p>Monitoramento de performance</p>
              </CardContent>
            </Card>
            <Card className="border-2 border-l-4 border-l-purple-500 text-center">
              <CardHeader className="pb-2">
                <Badge className="mx-auto mb-2">S</Badge>
                <CardTitle className="text-sm">Security</CardTitle>
              </CardHeader>
              <CardContent className="text-xs">
                <p>Proteção e controle de acesso</p>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>

      {/* F - Fault Management */}
      <Card className="mb-6 border-2 border-l-red-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-6 w-6 text-red-500" />
            F - Fault Management (Gerenciamento de Falhas)
          </CardTitle>
          <CardDescription>Detecção, isolamento e correção de problemas</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm"><strong>Objetivo:</strong> Detectar, isolar, corrigir e registrar falhas na rede para manter a operação normal.</p>

          <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
            <h4 className="font-semibold mb-2">Processo de Gerenciamento de Falhas</h4>
            <ol className="list-decimal list-inside ml-4 space-y-1 text-sm">
              <li><strong>Detecção:</strong> Identificar que uma falha ocorreu (traps, syslog, alertas)</li>
              <li><strong>Diagnóstico:</strong> Determinar a causa raiz do problema</li>
              <li><strong>Isolamento:</strong> Limitar o impacto da falha</li>
              <li><strong>Correção:</strong> Reparar ou contornar o problema</li>
              <li><strong>Recuperação:</strong> Restaurar o serviço normal</li>
              <li><strong>Registro:</strong> Documentar o incidente para análise futura</li>
            </ol>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="fault-mechanisms">
              <AccordionTrigger className="text-left text-sm font-medium">
                🔧 Mecanismos de Detecção
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li><strong>SNMP Traps:</strong> Mensagens assíncronas enviadas pelo dispositivo</li>
                  <li><strong>Syslog:</strong> Mensagens de log enviadas para servidor central</li>
                  <li><strong>Polling:</strong> Consultas periódicas de status (SNMP GET)</li>
                  <li><strong>Thresholds:</strong> Limites configurados que geram alertas</li>
                  <li><strong>Heartbeat:</strong> Sinais de vida periódicos</li>
                  <li><strong>BFD (Bidirectional Forwarding Detection):</strong> Detecção rápida de falhas</li>
                </ul>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="mttr-mtbf">
              <AccordionTrigger className="text-left text-sm font-medium">
                📊 Métricas de Disponibilidade
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <div className="p-3 bg-muted rounded space-y-2">
                  <p><strong>MTBF (Mean Time Between Failures):</strong></p>
                  <p className="text-xs ml-4">Tempo médio entre falhas. Quanto maior, mais confiável.</p>
                  <p className="mt-2"><strong>MTTR (Mean Time To Repair):</strong></p>
                  <p className="text-xs ml-4">Tempo médio para reparar. Quanto menor, melhor.</p>
                  <p className="mt-2"><strong>Availability (Disponibilidade):</strong></p>
                  <p className="text-xs ml-4">Availability = MTBF / (MTBF + MTTR)</p>
                  <p className="text-xs ml-4 mt-1">Exemplo: 99.999% (Five Nines) = ~5 minutos de downtime/ano</p>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* C - Configuration Management */}
      <Card className="mb-6 border-2 border-l-blue-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-6 w-6 text-blue-500" />
            C - Configuration Management (Gerenciamento de Configuração)
          </CardTitle>
          <CardDescription>Controle e manutenção de configurações de rede</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm"><strong>Objetivo:</strong> Gerenciar mudanças, manter inventário e controlar versões de configurações.</p>

          <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
            <h4 className="font-semibold mb-2">Funções Principais</h4>
            <ul className="list-disc list-inside ml-4 space-y-1 text-sm">
              <li><strong>Inventário:</strong> Manter lista de todos os dispositivos e suas configurações</li>
              <li><strong>Backup:</strong> Backup periódico de configurações</li>
              <li><strong>Versionamento:</strong> Controle de versões e histórico de mudanças</li>
              <li><strong>Change Management:</strong> Processo controlado para implementar mudanças</li>
              <li><strong>Compliance:</strong> Garantir conformidade com políticas</li>
              <li><strong>Automation:</strong> Automatizar configurações repetitivas</li>
            </ul>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="config-lifecycle">
              <AccordionTrigger className="text-left text-sm font-medium">
                🔄 Ciclo de Vida da Configuração
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <ol className="list-decimal list-inside ml-4 space-y-1">
                  <li><strong>Planejamento:</strong> Definir mudanças necessárias</li>
                  <li><strong>Teste:</strong> Validar em ambiente de teste</li>
                  <li><strong>Aprovação:</strong> Obter autorização</li>
                  <li><strong>Implementação:</strong> Aplicar mudanças (maintenance window)</li>
                  <li><strong>Verificação:</strong> Confirmar que funcionou</li>
                  <li><strong>Documentação:</strong> Registrar mudanças</li>
                  <li><strong>Rollback:</strong> Plano de retorno caso falhe</li>
                </ol>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="config-tools">
              <AccordionTrigger className="text-left text-sm font-medium">
                🛠️ Ferramentas e Tecnologias
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li><strong>NETCONF/RESTCONF:</strong> Protocolos de configuração programável</li>
                  <li><strong>YANG:</strong> Modelagem de dados para configuração</li>
                  <li><strong>Ansible/Terraform:</strong> Automação de configuração</li>
                  <li><strong>Git:</strong> Controle de versão de configurações</li>
                  <li><strong>CI/CD:</strong> Integração contínua para mudanças de rede</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* A - Accounting Management */}
      <Card className="mb-6 border-2 border-l-emerald-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-6 w-6 text-emerald-500" />
            A - Accounting Management (Gerenciamento de Contabilidade)
          </CardTitle>
          <CardDescription>Rastreamento de uso de recursos e billing</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm"><strong>Objetivo:</strong> Medir e registrar o uso de recursos para billing, planejamento de capacidade e compliance.</p>

          <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-lg">
            <h4 className="font-semibold mb-2">Funções Principais</h4>
            <ul className="list-disc list-inside ml-4 space-y-1 text-sm">
              <li><strong>Coleta de Dados:</strong> Registrar uso de recursos (banda, tempo, serviços)</li>
              <li><strong>Billing:</strong> Base para cobrança de serviços</li>
              <li><strong>Capacity Planning:</strong> Planejamento de capacidade baseado em uso</li>
              <li><strong>Auditoria:</strong> Rastrear quem usou o quê e quando</li>
              <li><strong>Cost Allocation:</strong> Alocar custos por departamento/usuário</li>
            </ul>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="accounting-protocols">
              <AccordionTrigger className="text-left text-sm font-medium">
                📡 Protocolos de Accounting
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <div className="p-3 bg-muted rounded">
                  <p><strong>RADIUS Accounting:</strong></p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1 mt-1">
                    <li>Porta UDP 1813</li>
                    <li>Usado com autenticação RADIUS</li>
                    <li>Coleta informações de sessão</li>
                  </ul>
                </div>
                <div className="p-3 bg-muted rounded">
                  <p><strong>TACACS+ Accounting:</strong></p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1 mt-1">
                    <li>Protocolo separado de autenticação</li>
                    <li>Mais detalhado que RADIUS</li>
                    <li>Usado em ambientes Cisco</li>
                  </ul>
                </div>
                <div className="p-3 bg-muted rounded">
                  <p><strong>NetFlow/sFlow:</strong></p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1 mt-1">
                    <li>Coleta de dados de tráfego</li>
                    <li>Análise de padrões de uso</li>
                    <li>Planejamento de capacidade</li>
                  </ul>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* P - Performance Management */}
      <Card className="mb-6 border-2 border-l-amber-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-6 w-6 text-amber-500" />
            P - Performance Management (Gerenciamento de Performance)
          </CardTitle>
          <CardDescription>Monitoramento e otimização de performance</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm"><strong>Objetivo:</strong> Monitorar, medir e otimizar a performance da rede para garantir SLAs.</p>

          <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg">
            <h4 className="font-semibold mb-2">Métricas de Performance</h4>
            <div className="grid md:grid-cols-2 gap-2 text-sm">
              <ul className="list-disc list-inside space-y-1">
                <li><strong>Largura de Banda:</strong> Taxa de transferência</li>
                <li><strong>Latência:</strong> Tempo de resposta</li>
                <li><strong>Jitter:</strong> Variação na latência</li>
              </ul>
              <ul className="list-disc list-inside space-y-1">
                <li><strong>Throughput:</strong> Dados entregues por segundo</li>
                <li><strong>Packet Loss:</strong> Perda de pacotes</li>
                <li><strong>Erro Rate:</strong> Taxa de erros</li>
              </ul>
            </div>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="sla">
              <AccordionTrigger className="text-left text-sm font-medium">
                📋 SLA (Service Level Agreement)
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Definição:</strong> Contrato que define níveis de serviço acordados entre provedor e cliente.</p>
                <div className="p-3 bg-muted rounded space-y-1 mt-2">
                  <p className="font-semibold text-xs">Exemplos de SLAs:</p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1">
                    <li>Disponibilidade: 99.9% (8.76h downtime/ano)</li>
                    <li>Latência: &lt;50ms (média)</li>
                    <li>Packet Loss: &lt;0.1%</li>
                    <li>Jitter: &lt;10ms</li>
                    <li>Tempo de reparo: &lt;4 horas</li>
                  </ul>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="baselining">
              <AccordionTrigger className="text-left text-sm font-medium">
                📊 Baseline e Tendências
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Baseline:</strong> Medição de performance normal da rede em condições estáveis.</p>
                <p><strong>Trend Analysis:</strong> Análise de tendências para prever problemas e planejar upgrades.</p>
                <p><strong>Capacity Planning:</strong> Planejamento de capacidade baseado em crescimento observado.</p>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* S - Security Management */}
      <Card className="mb-8 border-2 border-l-purple-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShieldCheck className="h-6 w-6 text-purple-500" />
            S - Security Management (Gerenciamento de Segurança)
          </CardTitle>
          <CardDescription>Proteção, controle de acesso e conformidade</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm"><strong>Objetivo:</strong> Proteger a rede contra acessos não autorizados, ataques e garantir confidencialidade, integridade e disponibilidade.</p>

          <div className="p-4 bg-purple-500/10 border border-purple-500/20 rounded-lg">
            <h4 className="font-semibold mb-2">Áreas de Segurança</h4>
            <ul className="list-disc list-inside ml-4 space-y-1 text-sm">
              <li><strong>Autenticação:</strong> Verificar identidade de usuários/dispositivos</li>
              <li><strong> Autorização:</strong> Controlar o que pode ser acessado</li>
              <li><strong>Accounting:</strong> Registrar ações (auditoria)</li>
              <li><strong>Confidencialidade:</strong> Proteger dados contra acesso não autorizado</li>
              <li><strong>Integridade:</strong> Garantir que dados não foram alterados</li>
              <li><strong>Disponibilidade:</strong> Garantir acesso quando necessário</li>
              <li><strong>Não-repúdio:</strong> Garantir que ações não possam ser negadas</li>
            </ul>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="security-controls">
              <AccordionTrigger className="text-left text-sm font-medium">
                🛡️ Controles de Segurança
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <div className="space-y-2">
                  <p><strong>Controles Técnicos:</strong></p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1">
                    <li>Firewalls, IPS/IDS, WAF</li>
                    <li>VPN, Criptografia</li>
                    <li>802.1X (Network Access Control)</li>
                    <li>Segmentação de rede (VLANs)</li>
                    <li>DNSSEC, BGPsec</li>
                  </ul>
                  <p className="mt-2"><strong>Controles Administrativos:</strong></p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1">
                    <li>Políticas de segurança</li>
                    <li>Treinamento de usuários</li>
                    <li>Procedimentos de incident response</li>
                    <li>Reviews de segurança</li>
                  </ul>
                  <p className="mt-2"><strong>Controles Físicos:</strong></p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1">
                    <li>Controle de acesso a data centers</li>
                    <li>Câmeras e monitoramento</li>
                    <li>Proteção contra desastres</li>
                  </ul>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="incident-response">
              <AccordionTrigger className="text-left text-sm font-medium">
                🚨 Incident Response
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <ol className="list-decimal list-inside ml-4 space-y-1">
                  <li><strong>Preparação:</strong> Políticas, ferramentas, treinamento</li>
                  <li><strong>Detecção:</strong> Identificar incidentes</li>
                  <li><strong>Contenção:</strong> Limitar o dano</li>
                  <li><strong>Erradicação:</strong> Remover a causa</li>
                  <li><strong>Recuperação:</strong> Restaurar operações</li>
                  <li><strong>Lessons Learned:</strong> Documentar e melhorar</li>
                </ol>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Integração FCAPS */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle>Integração das Áreas FCAPS</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm mb-4">As áreas do FCAPS são interdependentes e trabalham juntas para gerenciamento eficaz:</p>
          <ul className="list-disc list-inside ml-4 space-y-2 text-sm">
            <li><strong>Fault + Performance:</strong> Problemas de performance podem indicar falhas iminentes</li>
            <li><strong>Configuration + Security:</strong> Mudanças de configuração impactam a segurança</li>
            <li><strong>Accounting + Performance:</strong> Dados de uso ajudam no planejamento de capacidade</li>
            <li><strong>Security + Fault:</strong> Ataques podem causar falhas de rede</li>
            <li><strong>Configuration + All:</strong> Todas as áreas dependem de configurações corretas</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
