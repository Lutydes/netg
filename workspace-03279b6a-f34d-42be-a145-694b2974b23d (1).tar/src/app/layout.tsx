import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";
import Navigation from "@/components/navigation";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "NetworkG - Guia Completo de Redes e Certificações",
  description: "Guia completo e detalhado sobre redes de computadores, modelo OSI, hardware de rede, roteamento, gerenciamento FCAPS e tópicos avançados.",
  keywords: ["Network", "Redes", "OSI", "Hardware", "Roteamento", "FCAPS", "SNMP", "SDN", "Certificação"],
  authors: [{ name: "NetworkG Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "NetworkG - Guia Completo de Redes",
    description: "Guia completo sobre redes de computadores e certificações",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground min-h-screen flex flex-col`}
        suppressHydrationWarning
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange
        >
          <Navigation />
          <main className="flex-1">
            {children}
          </main>
          <footer className="border-t border-border/40 bg-card/50 backdrop-blur-sm mt-auto">
            <div className="container mx-auto px-4 py-6">
              <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                <div className="text-sm text-muted-foreground">
                  © 2025 NetworkG - Guia Completo de Redes
                </div>
                <div className="text-sm text-muted-foreground text-center md:text-right">
                  <p>Prof. MSc. Luis Fernando dos Santos Pires</p>
                  <p className="text-xs text-muted-foreground/70">Especialista em Gestão de Risco e Cybersegurança</p>
                </div>
                <div className="flex items-center gap-6 text-sm text-muted-foreground">
                  <a href="/" className="hover:text-primary transition-colors">Início</a>
                  <a href="/hardware" className="hover:text-primary transition-colors">Hardware</a>
                  <a href="/osi" className="hover:text-primary transition-colors">OSI</a>
                  <a href="/routing" className="hover:text-primary transition-colors">Roteamento</a>
                </div>
              </div>
            </div>
          </footer>
        </ThemeProvider>
        <Toaster />
      </body>
    </html>
  );
}
