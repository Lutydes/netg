import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Lock, BookOpen, Shield, ShieldAlert, ShieldCheck, Key, User, FileCheck, Network, AlertTriangle } from "lucide-react";

export default function SecurityPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      {/* Header */}
      <div className="mb-12">
        <div className="flex items-center gap-3 mb-4">
          <Lock className="h-10 w-10 text-primary" />
          <div>
            <h1 className="text-3xl md:text-4xl font-bold">Segurança em Redes</h1>
            <p className="text-muted-foreground text-lg">Proteção, Controle de Acesso e Defesa contra Ameaças</p>
          </div>
        </div>
        <Alert className="border-amber-500/50 bg-amber-500/10">
          <BookOpen className="h-4 w-4 text-amber-500" />
          <AlertDescription className="text-amber-200">
            <strong>Foco em Prova:</strong> Segurança de rede é um tópico crítico. Entenda CIA Triad, criptografia, autenticação e defesa em profundidade.
          </AlertDescription>
        </Alert>
      </div>

      {/* CIA Triad */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle>CIA Triad - Os Três Pilares da Segurança</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            <Card className="border-l-4 border-l-emerald-500">
              <CardHeader className="pb-2">
                <ShieldCheck className="h-8 w-8 text-emerald-500 mb-2" />
                <CardTitle className="text-base">Confidentiality (Confidencialidade)</CardTitle>
              </CardHeader>
              <CardContent className="text-sm">
                <p>Garantir que informações só sejam acessadas por pessoas autorizadas.</p>
                <ul className="list-disc list-inside ml-4 mt-2 text-xs space-y-1">
                  <li>Criptografia</li>
                  <li>Controle de acesso</li>
                  <li>Autenticação</li>
                  <li>Steganografia</li>
                </ul>
              </CardContent>
            </Card>
            <Card className="border-l-4 border-l-blue-500">
              <CardHeader className="pb-2">
                <FileCheck className="h-8 w-8 text-blue-500 mb-2" />
                <CardTitle className="text-base">Integrity (Integridade)</CardTitle>
              </CardHeader>
              <CardContent className="text-sm">
                <p>Garantir que dados não foram alterados sem autorização.</p>
                <ul className="list-disc list-inside ml-4 mt-2 text-xs space-y-1">
                  <li>Hash functions (SHA, MD5)</li>
                  <li>Assinaturas digitais</li>
                  <li>Checksums</li>
                  <li>Version control</li>
                </ul>
              </CardContent>
            </Card>
            <Card className="border-l-4 border-l-purple-500">
              <CardHeader className="pb-2">
                <Network className="h-8 w-8 text-purple-500 mb-2" />
                <CardTitle className="text-base">Availability (Disponibilidade)</CardTitle>
              </CardHeader>
              <CardContent className="text-sm">
                <p>Garantir que sistemas e dados estão disponíveis quando necessário.</p>
                <ul className="list-disc list-inside ml-4 mt-2 text-xs space-y-1">
                  <li>Redundância</li>
                  <li>Load balancing</li>
                  <li>Backup e recovery</li>
                  <li>DDoS protection</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>

      {/* Criptografia */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Key className="h-6 w-6 text-primary" />
            Criptografia
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="symmetric">
              <AccordionTrigger className="text-left text-sm font-medium">
                🔐 Criptografia Simétrica
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Definição:</strong> Usa a mesma chave para criptografar e descriptografar.</p>
                <div className="p-3 bg-muted rounded">
                  <p className="font-semibold text-xs">Algoritmos:</p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1 mt-1">
                    <li><strong>AES:</strong> Advanced Encryption Standard (128, 192, 256 bits) - Padrão atual</li>
                    <li><strong>DES/3DES:</strong> Data Encryption Standard (obsoleto/inseguro)</li>
                    <li><strong>RC4:</strong> Stream cipher (obsoleto)</li>
                    <li><strong>Blowfish/Twofish:</strong> Alternativas ao AES</li>
                  </ul>
                </div>
                <div className="p-3 bg-amber-500/10 rounded">
                  <p className="font-semibold text-xs">Vantagens:</p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1 mt-1">
                    <li>Rápido e eficiente</li>
                    <li>Bom para grandes volumes de dados</li>
                  </ul>
                  <p className="font-semibold text-xs mt-2">Desvantagens:</p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1 mt-1">
                    <li>Problema de distribuição de chaves</li>
                    <li>Não fornece não-repúdio</li>
                  </ul>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="asymmetric">
              <AccordionTrigger className="text-left text-sm font-medium">
                🔑 Criptografia Assimétrica
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Definição:</strong> Usa par de chaves (pública e privada). O que uma criptografa, só a outra descriptografa.</p>
                <div className="p-3 bg-muted rounded">
                  <p className="font-semibold text-xs">Algoritmos:</p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1 mt-1">
                    <li><strong>RSA:</strong> Baseado em fatoração de números primos</li>
                    <li><strong>ECC:</strong> Elliptic Curve Cryptography (menor chave, mesma segurança)</li>
                    <li><strong>Diffie-Hellman:</strong> Troca de chaves</li>
                    <li><strong>DSA:</strong> Digital Signature Algorithm</li>
                  </ul>
                </div>
                <div className="p-3 bg-emerald-500/10 rounded">
                  <p className="font-semibold text-xs">Aplicações:</p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1 mt-1">
                    <li><strong>Confidencialidade:</strong> Criptografa com chave pública, descriptografa com privada</li>
                    <li><strong>Assinatura Digital:</strong> Assina com privada, verifica com pública</li>
                    <li><strong>Troca de Chaves:</strong> Estabelecer chave simétrica de forma segura</li>
                  </ul>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="hash">
              <AccordionTrigger className="text-left text-sm font-medium">
                # Funções Hash
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Definição:</strong> Gera valor fixo de tamanho único para qualquer entrada. One-way function.</p>
                <div className="p-3 bg-muted rounded">
                  <p className="font-semibold text-xs">Algoritmos:</p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1 mt-1">
                    <li><strong>SHA-256:</strong> 256 bits (seguro, amplamente usado)</li>
                    <li><strong>SHA-3:</strong> Nova geração</li>
                    <li><strong>MD5:</strong> 128 bits (quebrado, não usar)</li>
                    <li><strong>Blake2:</strong> Alternativa rápida ao SHA-3</li>
                  </ul>
                </div>
                <div className="p-3 bg-blue-500/10 rounded">
                  <p className="font-semibold text-xs">Usos:</p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1 mt-1">
                    <li>Verificação de integridade de arquivos</li>
                    <li>Armazenamento seguro de senhas (com salt)</li>
                    <li>Assinaturas digitais</li>
                    <li>Merkle trees (blockchain)</li>
                  </ul>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="pkix">
              <AccordionTrigger className="text-left text-sm font-medium">
                📜 PKI e Certificados Digitais
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>PKI (Public Key Infrastructure):</strong> Infraestrutura de chaves públicas para gerenciar certificados digitais.</p>
                <div className="p-3 bg-muted rounded space-y-1">
                  <p className="font-semibold text-xs">Componentes PKI:</p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1">
                    <li><strong>CA (Certificate Authority):</strong> Emite certificados</li>
                    <li><strong>RA (Registration Authority):</strong> Valida identidade</li>
                    <li><strong>CRL:</strong> Certificate Revocation List</li>
                    <li><strong>OCSP:</strong> Online Certificate Status Protocol</li>
                  </ul>
                </div>
                <div className="p-3 bg-purple-500/10 rounded">
                  <p className="font-semibold text-xs">X.509 Certificate:</p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1 mt-1">
                    <li>Version, Serial Number</li>
                    <li>Subject, Issuer (CA)</li>
                    <li>Validity Period</li>
                    <li>Public Key</li>
                    <li>Signature (assinado pela CA)</li>
                  </ul>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Autenticação e Autorização */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-6 w-6 text-primary" />
            Autenticação e Autorização
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="aaa">
              <AccordionTrigger className="text-left text-sm font-medium">
                🔐 Modelo AAA
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <div className="grid md:grid-cols-3 gap-4">
                  <Card className="border-l-4 border-l-blue-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Authentication</CardTitle>
                    </CardHeader>
                    <CardContent className="text-xs">
                      <p><strong>Quem é você?</strong></p>
                      <p>Verifica identidade através de credenciais.</p>
                    </CardContent>
                  </Card>
                  <Card className="border-l-4 border-l-emerald-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Authorization</CardTitle>
                    </CardHeader>
                    <CardContent className="text-xs">
                      <p><strong>O que você pode fazer?</strong></p>
                      <p>Determina permissões e acesso a recursos.</p>
                    </CardContent>
                  </Card>
                  <Card className="border-l-4 border-l-purple-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Accounting</CardTitle>
                    </CardHeader>
                    <CardContent className="text-xs">
                      <p><strong>O que você fez?</strong></p>
                      <p>Registra ações para auditoria e billing.</p>
                    </CardContent>
                  </Card>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="mfa">
              <AccordionTrigger className="text-left text-sm font-medium">
                📱 MFA (Multi-Factor Authentication)
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Fatores de Autenticação:</strong></p>
                <ul className="list-disc list-inside ml-4 space-y-1 text-xs">
                  <li><strong>Something you know:</strong> Senha, PIN</li>
                  <li><strong>Something you have:</strong> Token, smartphone, smart card</li>
                  <li><strong>Something you are:</strong> Biometria (impressão digital, face, íris)</li>
                  <li><strong>Somewhere you are:</strong> Localização geográfica</li>
                </ul>
                <p className="mt-2"><strong>MFA implementations:</strong> TOTP (Google Authenticator), SMS, Push notifications, Hardware tokens (YubiKey)</p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="protocols">
              <AccordionTrigger className="text-left text-sm font-medium">
                🌐 Protocolos de Autenticação
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <div className="p-3 bg-muted rounded">
                  <p className="font-semibold text-xs">RADIUS:</p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1 mt-1">
                    <li>UDP 1812 (auth), 1813 (accounting)</li>
                    <li>Criptografia apenas da senha</li>
                    <li>Widely deployed</li>
                  </ul>
                </div>
                <div className="p-3 bg-muted rounded">
                  <p className="font-semibold text-xs">TACACS+:</p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1 mt-1">
                    <li>TCP 49</li>
                    <li>Todo o tráfego criptografado</li>
                    <li>Separa AAA em diferentes pacotes</li>
                    <li>Usado em ambientes Cisco</li>
                  </ul>
                </div>
                <div className="p-3 bg-muted rounded">
                  <p className="font-semibold text-xs">Kerberos:</p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1 mt-1">
                    <li>Ticket-based authentication</li>
                    <li>Uses symmetric cryptography</li>
                    <li>Prevents replay attacks</li>
                    <li>Windows AD uses Kerberos</li>
                  </ul>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Ameaças e Ataques */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShieldAlert className="h-6 w-6 text-primary" />
            Ameaças e Ataques Comuns
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <Card className="border-l-4 border-l-red-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Ataques de Rede</CardTitle>
              </CardHeader>
              <CardContent className="text-xs space-y-1">
                <p><strong>DDoS:</strong> Distributed Denial of Service</p>
                <p><strong>MITM:</strong> Man-in-the-Middle</p>
                <p><strong>ARP Spoofing:</strong> Falsificação ARP</p>
                <p><strong>DNS Spoofing:</strong> Envenenamento DNS</p>
                <p><strong>Sniffing:</strong> Captura de tráfego</p>
                <p><strong>Session Hijacking:</strong> Roubo de sessão</p>
              </CardContent>
            </Card>
            <Card className="border-l-4 border-l-orange-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Ataques de Aplicação</CardTitle>
              </CardHeader>
              <CardContent className="text-xs space-y-1">
                <p><strong>SQL Injection:</strong> Injeção de SQL</p>
                <p><strong>XSS:</strong> Cross-Site Scripting</p>
                <p><strong>CSRF:</strong> Cross-Site Request Forgery</p>
                <p><strong>Brute Force:</strong> Tentativa de senha</p>
                <p><strong>Phishing:</strong> Engenharia social</p>
                <p><strong>Ransomware:</strong> Sequestro de dados</p>
              </CardContent>
            </Card>
          </div>

          <Alert className="border-destructive/50 bg-destructive/10">
            <AlertTriangle className="h-4 w-4 text-destructive" />
            <AlertDescription className="text-destructive-foreground">
              <strong>Importante:</strong> Defesa em profundidade (Defense in Depth) é a melhor estratégia. Use múltiplas camadas de segurança.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      {/* VPN */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-6 w-6 text-primary" />
            VPN (Virtual Private Network)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="ipsec">
              <AccordionTrigger className="text-left text-sm font-medium">
                🔒 IPsec VPN
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Protocolos:</strong></p>
                <ul className="list-disc list-inside ml-4 text-xs space-y-1">
                  <li><strong>AH (Authentication Header):</strong> Autenticação e integridade (sem criptografia)</li>
                  <li><strong>ESP (Encapsulating Security Payload):</strong> Criptografia, autenticação e integridade</li>
                </ul>
                <p className="mt-2"><strong>Modos:</strong></p>
                <ul className="list-disc list-inside ml-4 text-xs space-y-1">
                  <li><strong>Transport Mode:</strong> Host-to-host (criptografa apenas payload)</li>
                  <li><strong>Tunnel Mode:</strong> Gateway-to-gateway (criptografa pacote inteiro)</li>
                </ul>
                <p className="mt-2"><strong>Key Exchange:</strong> IKEv1, IKEv2 (Diffie-Hellman)</p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="ssl-vpn">
              <AccordionTrigger className="text-left text-sm font-medium">
                🌐 SSL/TLS VPN
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Vantagens:</strong></p>
                <ul className="list-disc list-inside ml-4 text-xs space-y-1">
                  <li>Travessa NAT facilmente</li>
                  <li>Usa portas padrão (443)</li>
                  <li>Clientless (web-based)</li>
                  <li>Fácil de configurar</li>
                </ul>
                <p className="mt-2"><strong>Tipos:</strong></p>
                <ul className="list-disc list-inside ml-4 text-xs space-y-1">
                  <li><strong>Clientless VPN:</strong> Acesso via browser</li>
                  <li><strong>Thin Client:</strong> Instala lightweight client</li>
                  <li><strong>Full Tunnel:</strong> Todo tráfego via VPN</li>
                  <li><strong>Split Tunnel:</strong> Apenas tráfego corporativo via VPN</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* 802.1X */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle>802.1X - Network Access Control</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm mb-3"><strong>Arquitetura:</strong></p>
          <ul className="list-disc list-inside ml-4 text-sm space-y-1">
            <li><strong>Supplicant:</strong> Cliente (dispositivo solicitando acesso)</li>
            <li><strong>Authenticator:</strong> Switch/Access Point (porta de rede)</li>
            <li><strong>Authentication Server:</strong> RADIUS Server (valida credenciais)</li>
          </ul>
          <p className="text-sm mt-3"><strong>EAP Methods:</strong> EAP-TLS (certificados), PEAP (senha), EAP-TTLS, EAP-FAST</p>
        </CardContent>
      </Card>
    </div>
  );
}
