import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Cloud, BookOpen, Server, Database, Globe, Shield, Zap, Layers, Scale } from "lucide-react";

export default function CloudPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      {/* Header */}
      <div className="mb-12">
        <div className="flex items-center gap-3 mb-4">
          <Cloud className="h-10 w-10 text-primary" />
          <div>
            <h1 className="text-3xl md:text-4xl font-bold">Cloud Computing</h1>
            <p className="text-muted-foreground text-lg">Computação em Nuvem - Modelos, Serviços e Arquiteturas</p>
          </div>
        </div>
        <Alert className="border-amber-500/50 bg-amber-500/10">
          <BookOpen className="h-4 w-4 text-amber-500" />
          <AlertDescription className="text-amber-200">
            <strong>Foco em Prova:</strong> Cloud computing é essencial. Entenda IaaS/PaaS/SaaS, deployment models e conceitos fundamentais.
          </AlertDescription>
        </Alert>
      </div>

      {/* O que é Cloud Computing */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle>O que é Cloud Computing?</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm mb-4">
            Cloud Computing é a entrega de serviços de computação (servidores, armazenamento, banco de dados, rede, software, etc.) pela Internet.
          </p>
          <div className="p-4 bg-primary/10 border border-primary/20 rounded-lg">
            <h4 className="font-semibold mb-2">Características Essenciais (NIST):</h4>
            <ul className="list-disc list-inside ml-4 space-y-1 text-sm">
              <li><strong>On-demand self-service:</strong> Provisionamento automático sem intervenção humana</li>
              <li><strong>Broad network access:</strong> Acesso via rede padrão (Internet)</li>
              <li><strong>Resource pooling:</strong> Recursos compartilhados (multi-tenancy)</li>
              <li><strong>Rapid elasticity:</strong> Escalar rapidamente para cima ou para baixo</li>
              <li><strong>Measured service:</strong> Pay-as-you-go, monitoramento de uso</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Modelos de Serviço */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Layers className="h-6 w-6 text-primary" />
            Modelos de Serviço (Service Models)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-3 gap-4">
            <Card className="border-2 border-l-purple-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">IaaS</CardTitle>
                <CardDescription className="text-xs">Infrastructure as a Service</CardDescription>
              </CardHeader>
              <CardContent className="text-sm space-y-2">
                <p><strong>Definição:</strong> Infraestrutura computacional provisionada como serviço.</p>
                <div className="p-2 bg-purple-500/10 rounded text-xs">
                  <p className="font-semibold">Você gerencia:</p>
                  <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                    <li>Aplicações</li>
                    <li>Dados</li>
                    <li>Runtime</li>
                    <li>Middleware</li>
                    <li>SO</li>
                  </ul>
                  <p className="font-semibold mt-2">Provedor gerencia:</p>
                  <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                    <li>Virtualização</li>
                    <li>Servidores</li>
                    <li>Armazenamento</li>
                    <li>Rede</li>
                  </ul>
                </div>
                <p className="text-xs"><strong>Exemplos:</strong> AWS EC2, Azure VM, Google Compute Engine</p>
              </CardContent>
            </Card>

            <Card className="border-2 border-l-blue-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">PaaS</CardTitle>
                <CardDescription className="text-xs">Platform as a Service</CardDescription>
              </CardHeader>
              <CardContent className="text-sm space-y-2">
                <p><strong>Definição:</strong> Plataforma de desenvolvimento provisionada como serviço.</p>
                <div className="p-2 bg-blue-500/10 rounded text-xs">
                  <p className="font-semibold">Você gerencia:</p>
                  <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                    <li>Aplicações</li>
                    <li>Dados</li>
                  </ul>
                  <p className="font-semibold mt-2">Provedor gerencia:</p>
                  <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                    <li>Runtime</li>
                    <li>Middleware</li>
                    <li>SO</li>
                    <li>Virtualização</li>
                    <li>Servidores</li>
                  </ul>
                </div>
                <p className="text-xs"><strong>Exemplos:</strong> AWS Elastic Beanstalk, Heroku, Google App Engine</p>
              </CardContent>
            </Card>

            <Card className="border-2 border-l-emerald-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">SaaS</CardTitle>
                <CardDescription className="text-xs">Software as a Service</CardDescription>
              </CardHeader>
              <CardContent className="text-sm space-y-2">
                <p><strong>Definição:</strong> Software provisionado como serviço através da Internet.</p>
                <div className="p-2 bg-emerald-500/10 rounded text-xs">
                  <p className="font-semibold">Você gerencia:</p>
                  <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                    <li>Alguns dados/configurações</li>
                  </ul>
                  <p className="font-semibold mt-2">Provedor gerencia:</p>
                  <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                    <li>Tudo (Aplicação a infraestrutura)</li>
                  </ul>
                </div>
                <p className="text-xs"><strong>Exemplos:</strong> Gmail, Office 365, Salesforce, Dropbox</p>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>

      {/* Modelos de Deployment */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-6 w-6 text-primary" />
            Modelos de Deployment (Deployment Models)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            <Card className="border-l-4 border-l-blue-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Public Cloud</CardTitle>
              </CardHeader>
              <CardContent className="text-xs">
                <p>Recursos compartilhados, acessíveis pelo público geral.</p>
                <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                  <li>Baixo custo inicial</li>
                  <li>Sem manutenção de infraestrutura</li>
                  <li>Escalabilidade ilimitada</li>
                  <li>Menor controle sobre segurança</li>
                </ul>
                <p className="mt-2"><strong>Ex:</strong> AWS, Azure, GCP</p>
              </CardContent>
            </Card>
            <Card className="border-l-4 border-l-purple-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Private Cloud</CardTitle>
              </CardHeader>
              <CardContent className="text-xs">
                <p>Recursos dedicados a uma organização.</p>
                <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                  <li>Maior controle e segurança</li>
                  <li>Compliance facilitado</li>
                  <li>Alto custo de infraestrutura</li>
                  <li>Requer equipe dedicada</li>
                </ul>
                <p className="mt-2"><strong>Ex:</strong> VMware vSphere, OpenStack, Azure Stack</p>
              </CardContent>
            </Card>
            <Card className="border-l-4 border-l-emerald-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Hybrid Cloud</CardTitle>
              </CardHeader>
              <CardContent className="text-xs">
                <p>Combinação de public e private cloud.</p>
                <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                  <li>Flexibilidade de workload</li>
                  <li>Cloud bursting para picos</li>
                  <li>Complexidade de gerenciamento</li>
                  <li>Requer integração cuidadosa</li>
                </ul>
              </CardContent>
            </Card>
            <Card className="border-l-4 border-l-amber-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Community Cloud</CardTitle>
              </CardHeader>
              <CardContent className="text-xs">
                <p>Compartilhado por várias organizações com interesses comuns.</p>
                <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                  <li>Compartilha custos</li>
                  <li>Objetivos em comum</li>
                  <li>Maior que private, menor que public</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>

      {/* Serviços Cloud Comuns */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Server className="h-6 w-6 text-primary" />
            Serviços Cloud Comuns
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="compute">
              <AccordionTrigger className="text-left text-sm font-medium">
                ⚙️ Compute (Computação)
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <ul className="list-disc list-inside ml-4 space-y-1 text-xs">
                  <li><strong>EC2 (AWS):</strong> Virtual Machines</li>
                  <li><strong>Azure VM:</strong> Virtual Machines</li>
                  <li><strong>Google Compute Engine:</strong> Virtual Machines</li>
                  <li><strong>Lambda (AWS):</strong> Serverless, Functions as a Service</li>
                  <li><strong>Azure Functions:</strong> Serverless</li>
                  <li><strong>Google Cloud Functions:</strong> Serverless</li>
                  <li><strong>ECR/EKS:</strong> Container Registry/Service</li>
                  <li><strong>Azure AKS:</strong> Kubernetes Service</li>
                </ul>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="storage">
              <AccordionTrigger className="text-left text-sm font-medium">
                💾 Storage (Armazenamento)
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <div className="p-3 bg-muted rounded space-y-1">
                  <p className="font-semibold text-xs">Tipos de Storage:</p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1">
                    <li><strong>Object Storage:</strong> S3, Azure Blob, GCS (não-estruturado)</li>
                    <li><strong>Block Storage:</strong> EBS, Azure Disk (para VMs)</li>
                    <li><strong>File Storage:</strong> EFS, Azure Files (NFS/SMB)</li>
                    <li><strong>Archive:</strong> Glacier, Azure Archive (custo baixo, lento)</li>
                  </ul>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="database">
              <AccordionTrigger className="text-left text-sm font-medium">
                🗄️ Database (Banco de Dados)
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <div className="p-3 bg-muted rounded space-y-1">
                  <p className="font-semibold text-xs">Managed Databases:</p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1">
                    <li><strong>Relational:</strong> RDS (AWS), Azure SQL, Cloud SQL (GCP)</li>
                    <li><strong>NoSQL:</strong> DynamoDB, Cosmos DB, Firestore</li>
                    <li><strong>In-Memory:</strong> ElastiCache, Azure Cache, Memorystore</li>
                    <li><strong>Data Warehouse:</strong> Redshift, Snowflake, BigQuery</li>
                  </ul>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="network">
              <AccordionTrigger className="text-left text-sm font-medium">
                🌐 Network (Rede)
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <ul className="list-disc list-inside ml-4 space-y-1 text-xs">
                  <li><strong>VPC (Virtual Private Cloud):</strong> Rede isolada</li>
                  <li><strong>Load Balancing:</strong> ELB, Azure Load Balancer</li>
                  <li><strong>CDN:</strong> CloudFront, Cloudflare, Azure CDN</li>
                  <li><strong>DNS:</strong> Route 53, Azure DNS, Cloud DNS</li>
                  <li><strong>Direct Connect:</strong> Conexão dedicada</li>
                  <li><strong>VPN:</strong> Site-to-Site, Client VPN</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Conceitos Avançados */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-6 w-6 text-primary" />
            Conceitos Avançados
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="serverless">
              <AccordionTrigger className="text-left text-sm font-medium">
                ☁️ Serverless
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Definição:</strong> Código executado sem gerenciar servidores. Paga-se por execução/milissegundos.</p>
                <ul className="list-disc list-inside ml-4 text-xs space-y-1 mt-2">
                  <li>Auto-scaling automático</li>
                  <li>Zero custo quando não está em uso</li>
                  <li>Event-driven (triggers)</li>
                  <li>Stateless (usa storage externo)</li>
                </ul>
                <p className="mt-2"><strong>Use cases:</strong> APIs, webhooks, processamento de arquivos, IoT</p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="containers">
              <AccordionTrigger className="text-left text-sm font-medium">
                📦 Containers e Kubernetes
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Docker:</strong> Empacota aplicação e dependências em container</p>
                <p><strong>Kubernetes (K8s):</strong> Orquestração de containers</p>
                <ul className="list-disc list-inside ml-4 text-xs space-y-1 mt-2">
                  <li>Self-healing</li>
                  <li>Auto-scaling</li>
                  <li>Load balancing</li>
                  <li>Rolling updates/rollbacks</li>
                </ul>
                <p className="mt-2"><strong>Managed K8s:</strong> EKS, AKS, GKE</p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="microservices">
              <AccordionTrigger className="text-left text-sm font-medium">
                🔧 Microservices
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Definição:</strong> Arquitetura onde aplicação é dividida em serviços pequenos e independentes.</p>
                <ul className="list-disc list-inside ml-4 text-xs space-y-1 mt-2">
                  <li>Cada serviço pode ser desenvolvido e deployado independentemente</li>
                  <li>Escalabilidade granular</li>
                  <li>Resiliência (falha em um serviço não derruda tudo)</li>
                  <li>Complexidade aumentada (serviços de descoberta, config, etc.)</li>
                </ul>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="devops">
              <AccordionTrigger className="text-left text-sm font-medium">
                🚀 DevOps e CI/CD
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>CI (Continuous Integration):</strong> Integração contínua de código com testes automáticos.</p>
                <p><strong>CD (Continuous Deployment):</strong> Deploy automático após testes passarem.</p>
                <div className="p-3 bg-muted rounded mt-2">
                  <p className="font-semibold text-xs">Ferramentas:</p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1">
                    <li><strong>Version Control:</strong> Git, GitHub, GitLab</li>
                    <li><strong>CI/CD:</strong> Jenkins, GitHub Actions, GitLab CI, CircleCI</li>
                    <li><strong>IaC:</strong> Terraform, CloudFormation, ARM Templates</li>
                    <li><strong>Configuration:</strong> Ansible, Chef, Puppet</li>
                  </ul>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Segurança em Cloud */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-6 w-6 text-primary" />
            Segurança em Cloud
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="border-amber-500/50 bg-amber-500/10">
            <BookOpen className="h-4 w-4 text-amber-500" />
            <AlertDescription className="text-amber-200">
              <strong>Shared Responsibility Model:</strong> Segurança é responsabilidade compartilhada entre provedor e cliente.
            </AlertDescription>
          </Alert>

          <div className="p-4 bg-primary/10 border border-primary/20 rounded-lg">
            <h4 className="font-semibold mb-2">Responsabilidades por Modelo:</h4>
            <div className="grid md:grid-cols-3 gap-4 text-xs">
              <div>
                <p className="font-semibold">IaaS</p>
                <p><strong>Cliente:</strong> OS, apps, dados</p>
                <p><strong>Provedor:</strong> Infraestrutura física</p>
              </div>
              <div>
                <p className="font-semibold">PaaS</p>
                <p><strong>Cliente:</strong> Apps, dados</p>
                <p><strong>Provedor:</strong> OS, runtime, infra</p>
              </div>
              <div>
                <p className="font-semibold">SaaS</p>
                <p><strong>Cliente:</strong> Dados, configurações</p>
                <p><strong>Provedor:</strong> Tudo</p>
              </div>
            </div>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="iam">
              <AccordionTrigger className="text-left text-sm font-medium">
                🔐 IAM (Identity and Access Management)
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <ul className="list-disc list-inside ml-4 space-y-1 text-xs">
                  <li><strong>Users/Groups/Roles:</strong> Gerenciamento de identidades</li>
                  <li><strong>Policies:</strong> Definem permissões (JSON)</li>
                  <li><strong>MFA:</strong> Multi-factor authentication</li>
                  <li><strong>Least Privilege:</strong> Dar apenas permissões necessárias</li>
                  <li><strong>AWS IAM, Azure AD, GCP IAM</strong></li>
                </ul>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="encryption">
              <AccordionTrigger className="text-left text-sm font-medium">
                🔒 Encryption (Criptografia)
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <ul className="list-disc list-inside ml-4 space-y-1 text-xs">
                  <li><strong>Encryption at Rest:</strong> Dados armazenados criptografados (KMS, CMK)</li>
                  <li><strong>Encryption in Transit:</strong> TLS/SSL para dados em movimento</li>
                  <li><strong>Key Management:</strong> AWS KMS, Azure Key Vault, GCP KMS</li>
                  <li><strong>Customer Managed Keys (CMK):</strong> Você controla as chaves</li>
                </ul>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="compliance">
              <AccordionTrigger className="text-left text-sm font-medium">
                ✅ Compliance e Certificações
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <ul className="list-disc list-inside ml-4 space-y-1 text-xs">
                  <li><strong>ISO 27001:</strong> Segurança da informação</li>
                  <li><strong>SOC 2:</strong> Controles de segurança</li>
                  <li><strong>PCI DSS:</strong> Pagamentos com cartão</li>
                  <li><strong>HIPAA:</strong> Saúde (EUA)</li>
                  <li><strong>LGPD:</strong> Proteção de dados (Brasil)</li>
                  <li><strong>GDPR:</strong> Proteção de dados (Europa)</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Custos */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Scale className="h-6 w-6 text-primary" />
            Gerenciamento de Custos
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc list-inside ml-4 space-y-2 text-sm">
            <li><strong>Pay-as-you-go:</strong> Paga pelo que usa</li>
            <li><strong>Reserved Instances:</strong> Desconto por compromisso de 1-3 anos</li>
            <li><strong>Savings Plans:</strong> Desconto por uso consistente</li>
            <li><strong>Spot Instances:</strong> Excesso de capacidade, custo muito baixo, pode ser interrompido</li>
            <li><strong>Cost Optimization:</strong> Monitoramento, alerts, tag allocation</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
