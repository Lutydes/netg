import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Route, BookOpen, GitBranch, Globe, Network } from "lucide-react";

export default function RoutingPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      {/* Header */}
      <div className="mb-12">
        <div className="flex items-center gap-3 mb-4">
          <Route className="h-10 w-10 text-primary" />
          <div>
            <h1 className="text-3xl md:text-4xl font-bold">Protocolos de Roteamento</h1>
            <p className="text-muted-foreground text-lg">RIP, OSPF, BGP e Conceitos Fundamentais de Roteamento</p>
          </div>
        </div>
        <Alert className="border-amber-500/50 bg-amber-500/10">
          <BookOpen className="h-4 w-4 text-amber-500" />
          <AlertDescription className="text-amber-200">
            <strong>Foco em Prova:</strong> Roteamento é um tópico CRÍTICO. Entender distância administrativa, métricas e operação dos protocolos é essencial.
          </AlertDescription>
        </Alert>
      </div>

      {/* Conceitos Fundamentais */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle>Conceitos Fundamentais de Roteamento</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <Card className="border-l-4 border-l-blue-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Roteamento Estático</CardTitle>
              </CardHeader>
              <CardContent className="text-sm">
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li>Configurado manualmente</li>
                  <li>Predizível e seguro</li>
                  <li>Não consome recursos</li>
                  <li>Não escala bem</li>
                  <li>Sem autodiscovery</li>
                </ul>
              </CardContent>
            </Card>
            <Card className="border-l-4 border-l-purple-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Roteamento Dinâmico</CardTitle>
              </CardHeader>
              <CardContent className="text-sm">
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li>Aprende rotas automaticamente</li>
                  <li>Adapta a mudanças</li>
                  <li>Escalável</li>
                  <li>Consome CPU/memória</li>
                  <li>Complexidade de configuração</li>
                </ul>
              </CardContent>
            </Card>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="ad">
              <AccordionTrigger className="text-left text-sm font-medium">
                📊 Distância Administrativa (Administrative Distance)
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Definição:</strong> Mede a confiabilidade da fonte de rota. Menor valor = mais confiável.</p>
                <div className="overflow-x-auto mt-2">
                  <table className="w-full text-xs border">
                    <thead>
                      <tr className="bg-primary/10">
                        <th className="border p-2">Fonte de Rota</th>
                        <th className="border p-2">AD</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr><td className="border p-2">Connected Interface</td><td className="border p-2 font-mono">0</td></tr>
                      <tr><td className="border p-2">Static Route</td><td className="border p-2 font-mono">1</td></tr>
                      <tr><td className="border p-2">EIGRP (internal)</td><td className="border p-2 font-mono">90</td></tr>
                      <tr><td className="border p-2">IGRP</td><td className="border p-2 font-mono">100</td></tr>
                      <tr><td className="border p-2">OSPF</td><td className="border p-2 font-mono">110</td></tr>
                      <tr><td className="border p-2">IS-IS</td><td className="border p-2 font-mono">115</td></tr>
                      <tr><td className="border p-2">RIP</td><td className="border p-2 font-mono">120</td></tr>
                      <tr><td className="border p-2">EIGRP (external)</td><td className="border p-2 font-mono">170</td></tr>
                      <tr><td className="border p-2">BGP</td><td className="border p-2 font-mono">20 (external) / 200 (internal)</td></tr>
                    </tbody>
                  </table>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* RIP */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <GitBranch className="h-6 w-6 text-primary" />
            RIP (Routing Information Protocol)
          </CardTitle>
          <CardDescription>Protocolo de Vetor de Distância - Distance Vector</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="border-amber-500/50 bg-amber-500/10">
            <BookOpen className="h-4 w-4 text-amber-500" />
            <AlertDescription className="text-amber-200">
              <strong>Importante:</strong> RIP é um protocolo legado, mas ainda aparece em provas. Entenda suas limitações e operação.
            </AlertDescription>
          </Alert>

          <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
            <h4 className="font-semibold mb-2">Características Principais</h4>
            <ul className="list-disc list-inside ml-4 space-y-1 text-sm">
              <li><strong>Tipo:</strong> Distance Vector (vetor de distância)</li>
              <li><strong>Métrica:</strong> Hop count (número de saltos)</li>
              <li><strong>Máximo de hops:</strong> 15 (16 = infinito/unreachable)</li>
              <li><strong>Timer de atualização:</strong> 30 segundos</li>
              <li><strong>Porta:</strong> UDP 520</li>
              <li><strong>AD:</strong> 120</li>
            </ul>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="rip-versions">
              <AccordionTrigger className="text-left text-sm font-medium">
                📦 RIP v1 vs RIP v2
              </AccordionTrigger>
              <AccordionContent className="space-y-3 pt-3">
                <div className="grid md:grid-cols-2 gap-4">
                  <Card className="border-l-4 border-l-amber-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">RIP v1</CardTitle>
                    </CardHeader>
                    <CardContent className="text-xs space-y-1">
                      <p>• Classful (não envia máscara)</p>
                      <p>• Broadcast (255.255.255.255)</p>
                      <p>• Sem autenticação</p>
                      <p>• Não suporta VLSM</p>
                      <p>• Não suporta CIDR</p>
                    </CardContent>
                  </Card>
                  <Card className="border-l-4 border-l-emerald-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">RIP v2</CardTitle>
                    </CardHeader>
                    <CardContent className="text-xs space-y-1">
                      <p>• Classless (envia máscara)</p>
                      <p>• Multicast (224.0.0.9)</p>
                      <p>• Autenticação (texto/MD5)</p>
                      <p>• Suporta VLSM</p>
                      <p>• Suporta CIDR</p>
                    </CardContent>
                  </Card>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="rip-timers">
              <AccordionTrigger className="text-left text-sm font-medium">
                ⏱️ Timers do RIP
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li><strong>Update Timer (30s):</strong> Intervalo entre atualizações</li>
                  <li><strong>Invalid Timer (180s):</strong> Marca rota como inválida se não receber atualização</li>
                  <li><strong>Hold-down Timer (180s):</strong> Suprime rotas instáveis</li>
                  <li><strong>Flush Timer (240s):</strong> Remove rota da tabela se não recuperar</li>
                </ul>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="rip-problemas">
              <AccordionTrigger className="text-left text-sm font-medium">
                ⚠️ Problemas e Soluções
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <div className="space-y-2">
                  <p><strong>Count to Infinity:</strong> Loop onde hop count aumenta até 16</p>
                  <p className="ml-4 text-xs">Solução: Maximum hop count (16 = unreachable)</p>
                  <p><strong>Routing Loops:</strong> Pacotes em ciclo infinito</p>
                  <p className="ml-4 text-xs">Solução: Split Horizon, Route Poisoning, Hold-down Timers</p>
                  <p><strong>Slow Convergence:</strong> Demora para convergir após mudanças</p>
                  <p className="ml-4 text-xs">Solução: Triggered Updates</p>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* OSPF */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Network className="h-6 w-6 text-primary" />
            OSPF (Open Shortest Path First)
          </CardTitle>
          <CardDescription>Protocolo de Estado de Enlace - Link State</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="border-primary/50 bg-primary/10">
            <BookOpen className="h-4 w-4 text-primary" />
            <AlertDescription className="text-primary-foreground">
              <strong>Foco em Prova:</strong> OSPF é um dos protocolos MAIS importantes. Entenda LSAs, áreas, DR/BDR e tipos de rede.
            </AlertDescription>
          </Alert>

          <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-lg">
            <h4 className="font-semibold mb-2">Características Principais</h4>
            <ul className="list-disc list-inside ml-4 space-y-1 text-sm">
              <li><strong>Tipo:</strong> Link State (estado de enlace)</li>
              <li><strong>Métrica:</strong> Cost (baseado em bandwidth)</li>
              <li><strong>Algoritmo:</strong> Dijkstra (SPF - Shortest Path First)</li>
              <li><strong>Porta:</strong> Protocolo 89 (IP)</li>
              <li><strong>AD:</strong> 110</li>
              <li><strong>Classless:</strong> Suporta VLSM e CIDR</li>
              <li><strong>Hierárquico:</strong> Divide rede em áreas</li>
            </ul>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="ospf-areas">
              <AccordionTrigger className="text-left text-sm font-medium">
                🗺️ Áreas OSPF
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <div className="p-3 bg-muted rounded space-y-2">
                  <p><strong>Área 0 (Backbone):</strong> Obrigatória, todas as áreas conectam a ela</p>
                  <p><strong>Áreas Normais:</strong> Conectadas diretamente à área 0</p>
                  <p><strong>Áreas Stub:</strong> Não recebem rotas externas (LSA tipo 5)</p>
                  <p><strong>Áreas Totally Stub:</strong> Só recebem rota default (LSA tipo 3)</p>
                  <p><strong>Áreas NSSA (Not-So-Stubby):</strong> Permitem ASBRs</p>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="ospf-dr-bdr">
              <AccordionTrigger className="text-left text-sm font-medium">
                👥 DR e BDR (Designated Router)
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Propósito:</strong> Reduzir tráfego LSA em redes broadcast (Ethernet)</p>
                <ul className="list-disc list-inside ml-4 space-y-1 mt-2">
                  <li><strong>DR:</strong> Router designado, centraliza LSAs</li>
                  <li><strong>BDR:</strong> Backup DR, assume se DR falhar</li>
                  <li><strong>DROther:</strong> Outros routers</li>
                </ul>
                <p className="mt-2"><strong>Eleição:</strong> Baseada em Router ID e prioridade (padrão: 1). Prioridade 0 = não elegível.</p>
                <p className="mt-2"><strong>Tipos de Rede:</strong></p>
                <ul className="list-disc list-inside ml-4 space-y-1 text-xs">
                  <li>Broadcast (Ethernet) - Eleição DR/BDR</li>
                  <li>Point-to-Point - Sem eleição</li>
                  <li>Point-to-Multipoint - Sem eleição</li>
                  <li>Non-Broadcast - Eleição manual</li>
                </ul>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="ospf-lsa">
              <AccordionTrigger className="text-left text-sm font-medium">
                📋 LSAs (Link State Advertisements)
              </AccordionTrigger>
              <AccordionContent className="pt-2 text-sm">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs border">
                    <thead>
                      <tr className="bg-primary/10">
                        <th className="border p-2">Tipo</th>
                        <th className="border p-2">Nome</th>
                        <th className="border p-2">Descrição</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr><td className="border p-2">1</td><td className="border p-2">Router LSA</td><td className="border p-2">Rotas dentro da área</td></tr>
                      <tr><td className="border p-2">2</td><td className="border p-2">Network LSA</td><td className="border p-2">Rotas da rede (DR)</td></tr>
                      <tr><td className="border p-2">3</td><td className="border p-2">Summary LSA</td><td className="border p-2">Rotas entre áreas (ABR)</td></tr>
                      <tr><td className="border p-2">4</td><td className="border p-2">ASBR Summary</td><td className="border p-2">Caminho para ASBR</td></tr>
                      <tr><td className="border p-2">5</td><td className="border p-2">External LSA</td><td className="border p-2">Rotas externas (ASBR)</td></tr>
                      <tr><td className="border p-2">7</td><td className="border p-2">NSSA External</td><td className="border p-2">Rotas externas em NSSA</td></tr>
                    </tbody>
                  </table>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="ospf-estados">
              <AccordionTrigger className="text-left text-sm font-medium">
                🔄 Estados OSPF
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <ol className="list-decimal list-inside ml-4 space-y-1">
                  <li><strong>Down:</strong> Sem conexão</li>
                  <li><strong>Init:</strong> Hello recebido</li>
                  <li><strong>2-Way:</strong> Bi-direcional estabelecido</li>
                  <li><strong>ExStart:</strong> Eleição DR/BDR, Master/Slave</li>
                  <li><strong>Exchange:</strong> Troca de DBDs</li>
                  <li><strong>Loading:</strong> Troca de LSAs (LSR/LSU)</li>
                  <li><strong>Full:</strong> Adjacência completa</li>
                </ol>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* BGP */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-6 w-6 text-primary" />
            BGP (Border Gateway Protocol)
          </CardTitle>
          <CardDescription>Protocolo de Gateway de Borda - Roteamento entre ASes</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="border-primary/50 bg-primary/10">
            <BookOpen className="h-4 w-4 text-primary" />
            <AlertDescription className="text-primary-foreground">
              <strong>Foco em Prova:</strong> BGP é o protocolo da Internet. Entenda iBGP vs eBGP, atributos e peering.
            </AlertDescription>
          </Alert>

          <div className="p-4 bg-purple-500/10 border border-purple-500/20 rounded-lg">
            <h4 className="font-semibold mb-2">Características Principais</h4>
            <ul className="list-disc list-inside ml-4 space-y-1 text-sm">
              <li><strong>Tipo:</strong> Path Vector (vetor de caminho)</li>
              <li><strong>Porta:</strong> TCP 179</li>
              <li><strong>AD:</strong> 20 (eBGP), 200 (iBGP)</li>
              <li><strong>Uso:</strong> Roteamento entre Autonomous Systems (AS)</li>
              <li><strong>Métrica:</strong> Atributos (AS-Path, Local Preference, MED, etc.)</li>
              <li><strong>Slow Convergence:</strong> Focado em estabilidade, não velocidade</li>
            </ul>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="bgp-ibgp-ebgp">
              <AccordionTrigger className="text-left text-sm font-medium">
                🌐 iBGP vs eBGP
              </AccordionTrigger>
              <AccordionContent className="space-y-3 pt-3">
                <div className="grid md:grid-cols-2 gap-4">
                  <Card className="border-l-4 border-l-blue-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">iBGP (Internal BGP)</CardTitle>
                    </CardHeader>
                    <CardContent className="text-xs space-y-1">
                      <p>• Entre routers no mesmo AS</p>
                      <p>• AD: 200</p>
                      <p>• AS-Path não é alterado</p>
                      <p>• Next-Hop é preservado</p>
                      <p>• Requer Full Mesh ou Route Reflectors</p>
                      <p>• Não anuncia rotas iBGP para outros iBGP</p>
                    </CardContent>
                  </Card>
                  <Card className="border-l-4 border-l-emerald-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">eBGP (External BGP)</CardTitle>
                    </CardHeader>
                    <CardContent className="text-xs space-y-1">
                      <p>• Entre routers em ASes diferentes</p>
                      <p>• AD: 20</p>
                      <p>• Adiciona próprio AS ao AS-Path</p>
                      <p>• Altera Next-Hop para próprio IP</p>
                      <p>• TTL = 1 por padrão</p>
                      <p>• Peering direto ou multihop</p>
                    </CardContent>
                  </Card>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="bgp-atributos">
              <AccordionTrigger className="text-left text-sm font-medium">
                📊 Atributos BGP
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Ordem de Decisão (Best Path Selection):</strong></p>
                <ol className="list-decimal list-inside ml-4 space-y-1 text-xs mt-2">
                  <li>Highest Weight (Cisco)</li>
                  <li>Highest Local Preference</li>
                  <li>Locally originated (network/aggregate)</li>
                  <li>Shortest AS-Path</li>
                  <li>Lowest Origin Type (IGP &lt; EGP &lt; Incomplete)</li>
                  <li>Lowest MED</li>
                  <li>eBGP over iBGP</li>
                  <li>Lowest IGP metric to Next-Hop</li>
                  <li>If multipath enabled</li>
                  <li>Oldest eBGP path</li>
                  <li>Lowest Router ID</li>
                  <li>Lowest Neighbor IP</li>
                </ol>
                <p className="mt-2"><strong>Atributos Principais:</strong></p>
                <ul className="list-disc list-inside ml-4 space-y-1 text-xs">
                  <li><strong>AS-Path:</strong> Lista de ASes por onde passou</li>
                  <li><strong>Next-Hop:</strong> Próximo salto IP</li>
                  <li><strong>Local Preference:</strong> Preferência dentro do AS</li>
                  <li><strong>MED:</strong> Multi-Exit Discriminator (influencia saída)</li>
                  <li><strong>Origin:</strong> IGP, EGP, Incomplete</li>
                  <li><strong>Community:</strong> Tag para políticas</li>
                </ul>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="bgp-estados">
              <AccordionTrigger className="text-left text-sm font-medium">
                🔄 Estados BGP
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <ol className="list-decimal list-inside ml-4 space-y-1">
                  <li><strong>Idle:</strong> Aguardando evento de conexão</li>
                  <li><strong>Connect:</strong> Aguardando TCP 3-way handshake</li>
                  <li><strong>Active:</strong> Tentando estabelecer TCP</li>
                  <li><strong>OpenSent:</strong> Enviado OPEN, aguardando OPEN</li>
                  <li><strong>OpenConfirm:</strong> Recebido OPEN, aguardando KEEPALIVE</li>
                  <li><strong>Established:</strong> Conexão estabelecida, trocando updates</li>
                </ol>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Sub-rede */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle>Subnetting e CIDR</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm"><strong>CIDR (Classless Inter-Domain Routing):</strong> Permite divisão flexível de redes usando notação /prefixo</p>
          <div className="p-4 bg-muted rounded space-y-2 text-sm">
            <p><strong>Exemplos:</strong></p>
            <ul className="list-disc list-inside ml-4 space-y-1">
              <li>192.168.1.0/24 = 256 IPs (254 úteis)</li>
              <li>192.168.1.0/25 = 128 IPs (126 úteis)</li>
              <li>192.168.1.0/26 = 64 IPs (62 úteis)</li>
              <li>192.168.1.0/30 = 4 IPs (2 úteis - ponto a ponto)</li>
              <li>192.168.1.0/31 = 2 IPs (2 úteis - ponto a ponto RFC 3021)</li>
              <li>192.168.1.0/32 = 1 IP (host route)</li>
            </ul>
          </div>
          <p className="text-sm"><strong>Fórmula:</strong> 2^(32-n) - 2 = hosts úteis (onde n = prefixo)</p>
        </CardContent>
      </Card>
    </div>
  );
}
