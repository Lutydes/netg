import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import {
  Network,
  Shield,
  Layers,
  Route,
  BarChart3,
  Settings,
  ArrowRight,
  CheckCircle2,
  BookOpen,
  Target,
  Zap,
  Lock,
  Cloud,
  ArrowDown,
  ArrowUp,
  ArrowUpRight,
  ArrowDownLeft,
  ArrowDownRight,
  ArrowUpLeft,
} from "lucide-react";

const sections = [
  {
    href: "/hardware",
    icon: Shield,
    title: "Hardware de Rede",
    description: "Hubs, Bridges, Switches, Roteadores, Firewalls e dispositivos de segurança",
    topics: ["Switches L2/L3", "Tabela CAM", "VLANs", "Interfaces WAN/LAN", "IPS/IDS"],
    color: "bg-emerald-500/10 text-emerald-500 dark:bg-emerald-500/20",
  },
  {
    href: "/osi",
    icon: Layers,
    title: "Modelo OSI",
    description: "As 7 camadas do modelo OSI com todos os protocolos detalhados",
    topics: ["Camadas 1-7", "TCP/IP", "HTTP/HTTPS", "DNS", "Segurança"],
    color: "bg-amber-500/10 text-amber-500 dark:bg-amber-500/20",
  },
  {
    href: "/routing",
    icon: Route,
    title: "Protocolos de Roteamento",
    description: "RIP, OSPF, BGP e conceitos fundamentais de roteamento",
    topics: ["RIP v1/v2", "OSPF", "BGP", "Roteamento Estático", "Sub-rede"],
    color: "bg-purple-500/10 text-purple-500 dark:bg-purple-500/20",
  },
  {
    href: "/fcaps",
    icon: BarChart3,
    title: "Gerenciamento FCAPS",
    description: "Fault, Configuration, Accounting, Performance, Security",
    topics: ["Monitoramento", "Alertas", "SLA", "Auditoria", "Compliance"],
    color: "bg-rose-500/10 text-rose-500 dark:bg-rose-500/20",
  },
  {
    href: "/security",
    icon: Lock,
    title: "Segurança em Redes",
    description: "CIA Triad, Criptografia, Autenticação, VPN e Defesa contra Ataques",
    topics: ["Criptografia", "MFA", "IPsec VPN", "802.1X", "Firewalls"],
    color: "bg-red-500/10 text-red-500 dark:bg-red-500/20",
  },
  {
    href: "/cloud",
    icon: Cloud,
    title: "Cloud Computing",
    description: "IaaS, PaaS, SaaS, Serverless e Arquiteturas Cloud-Native",
    topics: ["IaaS/PaaS/SaaS", "Kubernetes", "DevOps", "Segurança Cloud", "Custos"],
    color: "bg-cyan-500/10 text-cyan-500 dark:bg-cyan-500/20",
  },
  {
    href: "/advanced",
    icon: Settings,
    title: "Tópicos Avançados",
    description: "SNMP, SDN, QoS, IPv6 e tecnologias modernas de rede",
    topics: ["SNMP v1/v2c/v3", "OpenFlow", "NFV", "MPLS", "QoS"],
    color: "bg-slate-500/10 text-slate-500 dark:bg-slate-500/20",
  },
];

const features = [
  { icon: BookOpen, title: "Conteúdo Detalhado", desc: "Cada tópico explicado com profundidade e exemplos práticos" },
  { icon: CheckCircle2, title: "Focado em Prova", desc: "Destaques e pontos importantes para certificações" },
  { icon: Target, title: "Organizado", desc: "Estrutura clara e navegável para fácil consulta" },
  { icon: Zap, title: "Rápido Acesso", desc: "Caixas expansíveis para conteúdo detalhado quando necessário" },
];

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-12">
      {/* Hero Section */}
      <div className="text-center mb-16">
        <div className="flex items-center justify-center gap-3 mb-6">
          <Network className="h-12 w-12 text-blue-500" />
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-500 to-blue-400 bg-clip-text text-transparent">
            NetworkG
          </h1>
        </div>
        <h2 className="text-2xl md:text-3xl font-semibold mb-4">
          Guia Completo de Redes de Computadores
        </h2>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
          Domine os conceitos fundamentais de redes de computadores com um guia completo, detalhado e focado em certificações.
          Do hardware ao software, do básico ao avançado.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <Button asChild size="lg" className="gap-2">
            <Link href="/osi">
              Começar pelo OSI
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link href="/hardware">
              Ver Hardware
              <Shield className="h-4 w-4 ml-2" />
            </Link>
          </Button>
        </div>
      </div>

      {/* Features */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
        {features.map((feature) => {
          const Icon = feature.icon;
          return (
            <Card key={feature.title} className="border-2 hover:border-primary/50 transition-colors">
              <CardHeader className="pb-3">
                <div className={`w-12 h-12 rounded-lg ${feature.title === "Conteúdo Detalhado" ? "bg-emerald-500/10" : feature.title === "Focado em Prova" ? "bg-amber-500/10" : feature.title === "Organizado" ? "bg-purple-500/10" : "bg-cyan-500/10"} flex items-center justify-center mb-3`}>
                  <Icon className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-base">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{feature.desc}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Mapa Conceitual de Redes */}
      <Card className="mb-12 border-2 border-primary/20 bg-gradient-to-br from-primary/5 via-transparent to-primary/5">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-2">
            <Network className="h-6 w-6 text-primary" />
            Mapa Conceitual de Redes
          </CardTitle>
          <CardDescription>Visão geral das conexões e relacionamentos entre os conceitos</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative min-h-[400px] overflow-hidden">
            {/* Central Node - Rede */}
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-10">
              <div className="w-24 h-24 rounded-full bg-primary text-primary-foreground flex flex-col items-center justify-center shadow-lg shadow-primary/20 border-4 border-primary">
                <Network className="h-10 w-10 mb-1" />
                <span className="text-xs font-bold text-center">REDES</span>
              </div>
            </div>

            {/* Hardware - Top */}
            <div className="absolute top-4 left-1/2 transform -translate-x-1/2">
              <Link href="/hardware" className="block">
                <div className="w-20 h-20 rounded-full bg-emerald-500/20 text-emerald-500 flex flex-col items-center justify-center border-2 border-emerald-500 hover:scale-110 transition-transform cursor-pointer">
                  <Shield className="h-8 w-8 mb-1" />
                  <span className="text-xs font-bold text-center">Hardware</span>
                </div>
              </Link>
              <div className="flex justify-center mt-1">
                <ArrowDown className="h-6 w-6 text-emerald-500/50" />
              </div>
            </div>

            {/* OSI - Top Right */}
            <div className="absolute top-16 right-8 md:right-20">
              <Link href="/osi" className="block">
                <div className="w-20 h-20 rounded-full bg-amber-500/20 text-amber-500 flex flex-col items-center justify-center border-2 border-amber-500 hover:scale-110 transition-transform cursor-pointer">
                  <Layers className="h-8 w-8 mb-1" />
                  <span className="text-xs font-bold text-center">OSI</span>
                </div>
              </Link>
              <div className="flex justify-center mt-1">
                <ArrowDownLeft className="h-6 w-6 text-amber-500/50" />
              </div>
            </div>

            {/* Routing - Right */}
            <div className="absolute top-1/2 right-4 md:right-8 transform -translate-y-1/2">
              <Link href="/routing" className="block">
                <div className="w-20 h-20 rounded-full bg-purple-500/20 text-purple-500 flex flex-col items-center justify-center border-2 border-purple-500 hover:scale-110 transition-transform cursor-pointer">
                  <Route className="h-8 w-8 mb-1" />
                  <span className="text-xs font-bold text-center">Roteamento</span>
                </div>
              </Link>
              <div className="flex justify-center mt-1">
                <ArrowDown className="h-6 w-6 text-purple-500/50 -rotate-90" />
              </div>
            </div>

            {/* Security - Bottom Right */}
            <div className="absolute bottom-16 right-8 md:right-20">
              <Link href="/security" className="block">
                <div className="w-20 h-20 rounded-full bg-red-500/20 text-red-500 flex flex-col items-center justify-center border-2 border-red-500 hover:scale-110 transition-transform cursor-pointer">
                  <Lock className="h-8 w-8 mb-1" />
                  <span className="text-xs font-bold text-center">Segurança</span>
                </div>
              </Link>
              <div className="flex justify-center mt-1">
                <ArrowDownLeft className="h-6 w-6 text-red-500/50 rotate-90" />
              </div>
            </div>

            {/* Cloud - Bottom */}
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
              <Link href="/cloud" className="block">
                <div className="w-20 h-20 rounded-full bg-cyan-500/20 text-cyan-500 flex flex-col items-center justify-center border-2 border-cyan-500 hover:scale-110 transition-transform cursor-pointer">
                  <Cloud className="h-8 w-8 mb-1" />
                  <span className="text-xs font-bold text-center">Cloud</span>
                </div>
              </Link>
              <div className="flex justify-center mt-1">
                <ArrowUp className="h-6 w-6 text-cyan-500/50" />
              </div>
            </div>

            {/* FCAPS - Bottom Left */}
            <div className="absolute bottom-16 left-8 md:left-20">
              <Link href="/fcaps" className="block">
                <div className="w-20 h-20 rounded-full bg-rose-500/20 text-rose-500 flex flex-col items-center justify-center border-2 border-rose-500 hover:scale-110 transition-transform cursor-pointer">
                  <BarChart3 className="h-8 w-8 mb-1" />
                  <span className="text-xs font-bold text-center">FCAPS</span>
                </div>
              </Link>
              <div className="flex justify-center mt-1">
                <ArrowUpRight className="h-6 w-6 text-rose-500/50 rotate-90" />
              </div>
            </div>

            {/* Advanced - Left */}
            <div className="absolute top-1/2 left-4 md:left-8 transform -translate-y-1/2">
              <Link href="/advanced" className="block">
                <div className="w-20 h-20 rounded-full bg-slate-500/20 text-slate-500 flex flex-col items-center justify-center border-2 border-slate-500 hover:scale-110 transition-transform cursor-pointer">
                  <Settings className="h-8 w-8 mb-1" />
                  <span className="text-xs font-bold text-center">Avançado</span>
                </div>
              </Link>
              <div className="flex justify-center mt-1">
                <ArrowDown className="h-6 w-6 text-slate-500/50 rotate-90" />
              </div>
            </div>

            {/* OSI - Top Left (duplicate for symmetry) */}
            <div className="absolute top-16 left-8 md:left-20">
              <Link href="/osi" className="block">
                <div className="w-20 h-20 rounded-full bg-amber-500/20 text-amber-500 flex flex-col items-center justify-center border-2 border-amber-500 hover:scale-110 transition-transform cursor-pointer">
                  <Layers className="h-8 w-8 mb-1" />
                  <span className="text-xs font-bold text-center">OSI</span>
                </div>
              </Link>
              <div className="flex justify-center mt-1">
                <ArrowDownRight className="h-6 w-6 text-amber-500/50" />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sections Grid */}
      <div className="mb-12">
        <h3 className="text-2xl font-bold text-center mb-8">Explore por Tópico</h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sections.map((section) => {
            const Icon = section.icon;
            return (
              <Card
                key={section.href}
                className="group border-2 hover:border-primary/50 transition-all hover:shadow-lg hover:shadow-primary/5"
              >
                <CardHeader>
                  <div className={`w-12 h-12 rounded-lg ${section.color} flex items-center justify-center mb-3`}>
                    <Icon className="h-6 w-6" />
                  </div>
                  <CardTitle className="group-hover:text-primary transition-colors">
                    {section.title}
                  </CardTitle>
                  <CardDescription className="text-base">
                    {section.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex flex-wrap gap-2">
                    {section.topics.map((topic) => (
                      <Badge key={topic} variant="secondary" className="text-xs">
                        {topic}
                      </Badge>
                    ))}
                  </div>
                  <Button asChild variant="ghost" className="w-full group-hover:bg-primary/10">
                    <Link href={section.href} className="gap-2">
                      Explorar
                      <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Study Path */}
      <Card className="border-2 border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-primary" />
            Caminho Recomendado de Estudo
          </CardTitle>
          <CardDescription className="text-base">
            Siga esta sequência para uma compreensão completa e estruturada
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 md:grid-cols-7 gap-4">
            {[
              { step: 1, title: "OSI", href: "/osi" },
              { step: 2, title: "Hardware", href: "/hardware" },
              { step: 3, title: "Roteamento", href: "/routing" },
              { step: 4, title: "Segurança", href: "/security" },
              { step: 5, title: "FCAPS", href: "/fcaps" },
              { step: 6, title: "Cloud", href: "/cloud" },
              { step: 7, title: "Avançado", href: "/advanced" },
            ].map((item) => (
              <Link
                key={item.step}
                href={item.href}
                className="text-center group"
              >
                <div className="w-14 h-14 md:w-16 md:h-16 mx-auto mb-2 rounded-full bg-primary/10 group-hover:bg-primary text-primary group-hover:text-primary-foreground flex items-center justify-center text-xl font-bold transition-all">
                  {item.step}
                </div>
                <div className="text-xs md:text-sm font-medium text-muted-foreground group-hover:text-primary transition-colors">
                  {item.title}
                </div>
              </Link>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
