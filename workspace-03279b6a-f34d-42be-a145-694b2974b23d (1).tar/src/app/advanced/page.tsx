import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Settings, BookOpen, Database, Network, Zap, Shield } from "lucide-react";

export default function AdvancedPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      {/* Header */}
      <div className="mb-12">
        <div className="flex items-center gap-3 mb-4">
          <Settings className="h-10 w-10 text-primary" />
          <div>
            <h1 className="text-3xl md:text-4xl font-bold">Tópicos Avançados</h1>
            <p className="text-muted-foreground text-lg">SNMP, SDN, QoS e Tecnologias Modernas de Rede</p>
          </div>
        </div>
        <Alert className="border-amber-500/50 bg-amber-500/10">
          <BookOpen className="h-4 w-4 text-amber-500" />
          <AlertDescription className="text-amber-200">
            <strong>Foco em Prova:</strong> Tópicos avançados como SNMP e SDN são cada vez mais importantes. Entenda conceitos, operação e aplicações.
          </AlertDescription>
        </Alert>
      </div>

      {/* SNMP */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-6 w-6 text-primary" />
            SNMP (Simple Network Management Protocol)
          </CardTitle>
          <CardDescription>Protocolo padrão para gerenciamento de redes</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="border-primary/50 bg-primary/10">
            <BookOpen className="h-4 w-4 text-primary" />
            <AlertDescription className="text-primary-foreground">
              <strong>Foco em Prova:</strong> SNMP é fundamental para gerenciamento de redes. Entenda versões, MIB, traps e operações.
            </AlertDescription>
          </Alert>

          <div className="p-4 bg-primary/10 border border-primary/20 rounded-lg">
            <h4 className="font-semibold mb-2">Conceitos Básicos</h4>
            <ul className="list-disc list-inside ml-4 space-y-1 text-sm">
              <li><strong>Arquitetura:</strong> Manager (NMS) + Agent (dispositivo)</li>
              <li><strong>MIB (Management Information Base):</strong> Banco de dados hierárquico de informações</li>
              <li><strong>OID (Object Identifier):</strong> Identificador único para cada objeto (ex: 1.3.6.1.2.1.1.1)</li>
              <li><strong>Portas:</strong> UDP 161 (polling), UDP 162 (traps)</li>
              <li><strong>Comunidade:</strong> String de autenticação (como senha)</li>
            </ul>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="snmp-versions">
              <AccordionTrigger className="text-left text-sm font-medium">
                📦 Versões SNMP
              </AccordionTrigger>
              <AccordionContent className="space-y-3 pt-3">
                <div className="space-y-3">
                  <Card className="border-l-4 border-l-amber-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">SNMPv1</CardTitle>
                    </CardHeader>
                    <CardContent className="text-xs space-y-1">
                      <p>• Comunidade em texto claro</p>
                      <p>• Sem criptografia</p>
                      <p>• Baseado em comunidade (public/private)</p>
                      <p>• Simples, mas inseguro</p>
                      <p>• Ainda usado em ambientes legados</p>
                    </CardContent>
                  </Card>
                  <Card className="border-l-4 border-l-blue-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">SNMPv2c</CardTitle>
                    </CardHeader>
                    <CardContent className="text-xs space-y-1">
                      <p>• Melhorias sobre v1</p>
                      <p>• GetBulkOperation (mais eficiente)</p>
                      <p>• 64-bit counters</p>
                      <p>• Ainda sem criptografia</p>
                      <p>• Mais comum que v1</p>
                    </CardContent>
                  </Card>
                  <Card className="border-l-4 border-l-emerald-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">SNMPv3</CardTitle>
                    </CardHeader>
                    <CardContent className="text-xs space-y-1">
                      <p>• Segurança robusta</p>
                      <p>• Autenticação (MD5, SHA)</p>
                      <p>• Criptografia (DES, AES)</p>
                      <p>• Controle de acesso baseado em usuário</p>
                      <p>• <strong>Recomendado para novos deployments</strong></p>
                    </CardContent>
                  </Card>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="snmp-operations">
              <AccordionTrigger className="text-left text-sm font-medium">
                ⚡ Operações SNMP
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs border">
                    <thead>
                      <tr className="bg-primary/10">
                        <th className="border p-2">Operação</th>
                        <th className="border p-2">Descrição</th>
                        <th className="border p-2">Direção</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr><td className="border p-2">GET</td><td className="border p-2">Recupera valor de um OID</td><td className="border p-2">Manager → Agent</td></tr>
                      <tr><td className="border p-2">GETNEXT</td><td className="border p-2">Recupera próximo OID na árvore</td><td className="border p-2">Manager → Agent</td></tr>
                      <tr><td className="border p-2">GETBULK</td><td className="border p-2">Recupera múltiplos valores (v2c+)</td><td className="border p-2">Manager → Agent</td></tr>
                      <tr><td className="border p-2">SET</td><td className="border p-2">Define valor de um OID</td><td className="border p-2">Manager → Agent</td></tr>
                      <tr><td className="border p-2">TRAP</td><td className="border p-2">Notificação assíncrona de evento</td><td className="border p-2">Agent → Manager</td></tr>
                      <tr><td className="border p-2">INFORM</td><td className="border p-2">Trap com confirmação (v2c+)</td><td className="border p-2">Agent → Manager</td></tr>
                    </tbody>
                  </table>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="snmp-mib">
              <AccordionTrigger className="text-left text-sm font-medium">
                🌳 MIB (Management Information Base)
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Estrutura Hierárquica:</strong></p>
                <div className="p-3 bg-muted rounded font-mono text-xs space-y-1 mt-2">
                  <p>iso (1)</p>
                  <p className="ml-4">├─ org (3)</p>
                  <p className="ml-8">├─ dod (6)</p>
                  <p className="ml-12">├─ internet (1)</p>
                  <p className="ml-16">├─ mgmt (2)</p>
                  <p className="ml-20">├─ mib-2 (1)</p>
                  <p className="ml-24">├─ system (1)</p>
                  <p className="ml-24">├─ interfaces (2)</p>
                  <p className="ml-24">└─ ip (4)</p>
                </div>
                <p className="mt-2"><strong>OID Exemplos:</strong></p>
                <ul className="list-disc list-inside ml-4 text-xs space-y-1">
                  <li>sysDescr: 1.3.6.1.2.1.1.1</li>
                  <li>sysUpTime: 1.3.6.1.2.1.1.3</li>
                  <li>ifNumber: 1.3.6.1.2.1.2.1</li>
                  <li>ifInOctets: 1.3.6.1.2.1.2.2.1.10</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* SDN */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Network className="h-6 w-6 text-primary" />
            SDN (Software Defined Networking)
          </CardTitle>
          <CardDescription>Redes definidas por software - Arquitetura moderna</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="border-primary/50 bg-primary/10">
            <BookOpen className="h-4 w-4 text-primary" />
            <AlertDescription className="text-primary-foreground">
              <strong>Foco em Prova:</strong> SDN é o futuro das redes. Entenda arquitetura, separação de planos e protocolos como OpenFlow.
            </AlertDescription>
          </Alert>

          <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-lg">
            <h4 className="font-semibold mb-2">Arquitetura SDN</h4>
            <ul className="list-disc list-inside ml-4 space-y-1 text-sm">
              <li><strong>Separação de Planos:</strong> Plano de controle e plano de dados separados</li>
              <li><strong>Controlador Centralizado:</strong> Inteligência da rede em um controlador</li>
              <li><strong>Programabilidade:</strong> Rede controlada por software/APIs</li>
              <li><strong>Abstração:</strong> A complexidade do hardware é abstraída</li>
              <li><strong>Automação:</strong> Provisionamento dinâmico e automático</li>
            </ul>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="sdn-planes">
              <AccordionTrigger className="text-left text-sm font-medium">
                📊 Planos da Rede SDN
              </AccordionTrigger>
              <AccordionContent className="space-y-3 pt-3">
                <div className="space-y-3">
                  <Card className="border-l-4 border-l-purple-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Plano de Controle (Control Plane)</CardTitle>
                    </CardHeader>
                    <CardContent className="text-xs space-y-1">
                      <p>• Toma decisões de roteamento</p>
                      <p>• Mantém estado da rede</p>
                      <p>• Executa algoritmos de roteamento</p>
                      <p>• Em SDN: Move para o controlador centralizado</p>
                    </CardContent>
                  </Card>
                  <Card className="border-l-4 border-l-blue-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Plano de Dados (Data Plane)</CardTitle>
                    </CardHeader>
                    <CardContent className="text-xs space-y-1">
                      <p>• Encaminha pacotes baseado em regras</p>
                      <p>• Alta velocidade (hardware/ASIC)</p>
                      <p>• Executa regras do controlador</p>
                      <p>• Switches/roteadores SDN</p>
                    </CardContent>
                  </Card>
                  <Card className="border-l-4 border-l-amber-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Plano de Gerenciamento (Management Plane)</CardTitle>
                    </CardHeader>
                    <CardContent className="text-xs space-y-1">
                      <p>• Configuração e monitoramento</p>
                      <p>• APIs (REST, NETCONF)</p>
                      <p>• Integração com orquestração</p>
                      <p>• Automação e DevOps</p>
                    </CardContent>
                  </Card>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="openflow">
              <AccordionTrigger className="text-left text-sm font-medium">
                🔄 OpenFlow
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Definição:</strong> Primeiro protocolo padrão de SDN para comunicação entre controlador e switches.</p>
                <div className="p-3 bg-muted rounded space-y-1 mt-2">
                  <p><strong>Componentes:</strong></p>
                  <ul className="list-disc list-inside ml-4 text-xs space-y-1">
                    <li><strong>Controlador:</strong> Aplicação que define regras</li>
                    <li><strong>Switch OpenFlow:</strong> Dispositivo que executa regras</li>
                    <li><strong>Channel Seguro:</strong> Conexão TLS entre controlador e switch</li>
                  </ul>
                </div>
                <p className="mt-2"><strong>Flow Table:</strong></p>
                <ul className="list-disc list-inside ml-4 text-xs space-y-1">
                  <li>Match fields: cabeçalhos de pacote (in-port, eth-src, eth-dst, IP, TCP, etc.)</li>
                  <li>Actions: forward, modify, drop, output to controller</li>
                  <li>Prioridade: ordem de matching</li>
                  <li>Counters: estatísticas do flow</li>
                </ul>
                <p className="mt-2"><strong>Mensagens OpenFlow:</strong></p>
                <ul className="list-disc list-inside ml-4 text-xs space-y-1">
                  <li>Controller-to-Switch: Features, Config, Modify-Flow, Packet-Out</li>
                  <li>Asynchronous: Packet-In, Flow-Removed, Port-Status</li>
                  <li>Symmetric: Hello, Echo, Error, Experimenter</li>
                </ul>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="sdn-architectures">
              <AccordionTrigger className="text-left text-sm font-medium">
                🏗️ Arquiteturas SDN
              </AccordionTrigger>
              <AccordionContent className="space-y-3 pt-3">
                <div className="space-y-3">
                  <Card className="border-l-4 border-l-emerald-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">OpenDaylight</CardTitle>
                    </CardHeader>
                    <CardContent className="text-xs space-y-1">
                      <p>• Open source, modular</p>
                      <p>• Suporta múltiplos protocolos (OpenFlow, NETCONF, BGP)</p>
                      <p>• Comunidade ativa</p>
                    </CardContent>
                  </Card>
                  <Card className="border-l-4 border-l-blue-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">ONOS (Open Network Operating System)</CardTitle>
                    </CardHeader>
                    <CardContent className="text-xs space-y-1">
                      <p>• Focado em performance e escalabilidade</p>
                      <p>• Distribuído, alta disponibilidade</p>
                      <p>• Usado em redes de operadora</p>
                    </CardContent>
                  </Card>
                  <Card className="border-l-4 border-l-purple-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Cisco ACI (Application Centric Infrastructure)</CardTitle>
                    </CardHeader>
                    <CardContent className="text-xs space-y-1">
                      <p>• SDN para data centers</p>
                      <p>• Policy-based</p>
                      <p>• Integra com VMware, Kubernetes</p>
                    </CardContent>
                  </Card>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* QoS */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-6 w-6 text-primary" />
            QoS (Quality of Service)
          </CardTitle>
          <CardDescription>Gerenciamento de qualidade de serviço</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm"><strong>Objetivo:</strong> Priorizar tráfego crítico e garantir performance para aplicações importantes.</p>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="qos-mechanisms">
              <AccordionTrigger className="text-left text-sm font-medium">
                ⚙️ Mecanismos de QoS
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li><strong>Classification & Marking:</strong> Classificar e marcar tráfego (DSCP, 802.1p)</li>
                  <li><strong>Queuing:</strong> Filas de prioridade (FIFO, PQ, CQ, WFQ, LLQ)</li>
                  <li><strong>Congestion Avoidance:</strong> WRED (Weighted Random Early Detection)</li>
                  <li><strong>Policing & Shaping:</strong> Controlar taxa de tráfego</li>
                  <li><strong>Link Efficiency:</strong> Compressão e LFI (Link Fragmentation)</li>
                </ul>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="dscp">
              <AccordionTrigger className="text-left text-sm font-medium">
                📊 DSCP (Differentiated Services Code Point)
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Definição:</strong> Campo de 6 bits no cabeçalho IP para classificação de tráfego.</p>
                <div className="overflow-x-auto mt-2">
                  <table className="w-full text-xs border">
                    <thead>
                      <tr className="bg-primary/10">
                        <th className="border p-2">Classe</th>
                        <th className="border p-2">DSCP</th>
                        <th className="border p-2">Uso</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr><td className="border p-2">Expedited Forwarding (EF)</td><td className="border p-2">46 (101110)</td><td className="border p-2">VoIP, baixa latência</td></tr>
                      <tr><td className="border p-2">Assured Forwarding (AF)</td><td className="border p-2">AF11-AF43</td><td className="border p-2">Video, aplicações de negócio</td></tr>
                      <tr><td className="border p-2">Best Effort (BE)</td><td className="border p-2">0 (000000)</td><td className="border p-2">Tráfego padrão</td></tr>
                    </tbody>
                  </table>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* IPv6 */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Network className="h-6 w-6 text-primary" />
            IPv6 Detalhado
          </CardTitle>
          <CardDescription>A nova geração do protocolo IP</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="ipv6-addressing">
              <AccordionTrigger className="text-left text-sm font-medium">
                🌍 Endereçamento IPv6
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Estrutura:</strong> 128 bits = 8 grupos de 16 bits em hexadecimal</p>
                <p><strong>Exemplo:</strong> 2001:0db8:85a3:0000:0000:8a2e:0370:7334</p>
                <p><strong>Regras:</strong></p>
                <ul className="list-disc list-inside ml-4 text-xs space-y-1">
                  <li>Zeros à esquerda podem ser omitidos: 2001:db8:85a3:0:0:8a2e:370:7334</li>
                  <li>Uma sequência de zeros pode ser abreviada com :: : 2001:db8:85a3::8a2e:370:7334</li>
                  <li>:: só pode ser usado uma vez</li>
                </ul>
                <p className="mt-2"><strong>Tipos de Endereços:</strong></p>
                <ul className="list-disc list-inside ml-4 text-xs space-y-1">
                  <li><strong>Unicast:</strong> Um-para-um (Global, Unique Local, Link-Local)</li>
                  <li><strong>Multicast:</strong> Um-para-muitos (ff00::/8)</li>
                  <li><strong>Anycast:</strong> Um-para-o-mais-próximo</li>
                </ul>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="ipv6-transition">
              <AccordionTrigger className="text-left text-sm font-medium">
                🔄 Mecanismos de Transição IPv4→IPv6
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li><strong>Dual Stack:</strong> Dispositivos suportam IPv4 e IPv6 simultaneamente</li>
                  <li><strong>Tunneling:</strong> IPv6 dentro de IPv4 (6to4, ISATAP, GRE)</li>
                  <li><strong>Translation:</strong> NAT64/DNS64 para IPv6-only acessar IPv4</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Segurança Avançada */}
      <Card className="mb-8 border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-6 w-6 text-primary" />
            Segurança Avançada
          </CardTitle>
          <CardDescription>Tópicos avançados de segurança de rede</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="802.1x">
              <AccordionTrigger className="text-left text-sm font-medium">
                🔐 802.1X (Port-Based Network Access Control)
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>Arquitetura:</strong></p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li><strong>Supplicant:</strong> Cliente (dispositivo que quer acesso)</li>
                  <li><strong>Authenticator:</strong> Switch/Access Point</li>
                  <li><strong>Authentication Server:</strong> RADIUS server</li>
                </ul>
                <p className="mt-2"><strong>EAP Methods:</strong> EAP-TLS, PEAP, EAP-TTLS, EAP-FAST</p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="vpn">
              <AccordionTrigger className="text-left text-sm font-medium">
                🌐 VPN Technologies
              </AccordionTrigger>
              <AccordionContent className="space-y-2 pt-2 text-sm">
                <p><strong>IPsec:</strong></p>
                <ul className="list-disc list-inside ml-4 text-xs space-y-1">
                  <li>Protocolos: AH (Authentication Header), ESP (Encapsulating Security Payload)</li>
                  <li>Modos: Transport (host-to-host), Tunnel (gateway-to-gateway)</li>
                  <li>Key Exchange: IKEv1, IKEv2</li>
                </ul>
                <p className="mt-2"><strong>SSL/TLS VPN:</strong></p>
                <ul className="list-disc list-inside ml-4 text-xs space-y-1">
                  <li>Clientless (web-based)</li>
                  <li>Thin client (SSL VPN client)</li>
                  <li>Fácil de usar, atravessa NAT</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>
    </div>
  );
}
